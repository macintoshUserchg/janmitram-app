/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-12.1.2-MariaDB, for osx10.21 (arm64)
--
-- Host: 127.0.0.1    Database: janmitram
-- ------------------------------------------------------
-- Server version	5.7.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `address_type` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `area` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `area_id` bigint(20) unsigned DEFAULT NULL,
  `road_no` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `flat_no` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `house_no` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_line` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_line2` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `post_code` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitude` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitude` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `addresses_customer_id_foreign` (`customer_id`),
  KEY `addresses_area_id_foreign` (`area_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `admin_coupons`
--

DROP TABLE IF EXISTS `admin_coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_coupons` (
  `coupon_id` bigint(20) unsigned NOT NULL,
  `shop_id` bigint(20) unsigned NOT NULL,
  KEY `admin_coupons_coupon_id_foreign` (`coupon_id`),
  KEY `admin_coupons_shop_id_foreign` (`shop_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_coupons`
--

LOCK TABLES `admin_coupons` WRITE;
/*!40000 ALTER TABLE `admin_coupons` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `admin_coupons` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `ads`
--

DROP TABLE IF EXISTS `ads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ads` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `media_id` bigint(20) unsigned DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ads_media_id_foreign` (`media_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ads`
--

LOCK TABLES `ads` WRITE;
/*!40000 ALTER TABLE `ads` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `ads` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `areas`
--

DROP TABLE IF EXISTS `areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `areas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `delivery_amount` double DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `areas`
--

LOCK TABLES `areas` WRITE;
/*!40000 ALTER TABLE `areas` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `areas` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `banners`
--

DROP TABLE IF EXISTS `banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `banners` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `media_id` bigint(20) unsigned DEFAULT NULL,
  `shop_id` bigint(20) unsigned DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `banners_media_id_foreign` (`media_id`),
  KEY `banners_shop_id_foreign` (`shop_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banners`
--

LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `banners` VALUES
(1,NULL,4,NULL,NULL,1,'2026-08-03 11:20:28','2026-08-03 11:20:28');
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `blog_tags`
--

DROP TABLE IF EXISTS `blog_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `blog_tags` (
  `blog_id` bigint(20) unsigned NOT NULL,
  `tag_id` bigint(20) unsigned NOT NULL,
  KEY `blog_tags_blog_id_foreign` (`blog_id`),
  KEY `blog_tags_tag_id_foreign` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_tags`
--

LOCK TABLES `blog_tags` WRITE;
/*!40000 ALTER TABLE `blog_tags` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `blog_tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `blog_views`
--

DROP TABLE IF EXISTS `blog_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `blog_views` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `blog_id` bigint(20) unsigned NOT NULL,
  `ip_address` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blog_views_blog_id_foreign` (`blog_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_views`
--

LOCK TABLES `blog_views` WRITE;
/*!40000 ALTER TABLE `blog_views` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `blog_views` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `blogs`
--

DROP TABLE IF EXISTS `blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `blogs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `title` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `media_id` bigint(20) unsigned DEFAULT NULL,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blogs_user_id_foreign` (`user_id`),
  KEY `blogs_media_id_foreign` (`media_id`),
  KEY `blogs_category_id_foreign` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blogs`
--

LOCK TABLES `blogs` WRITE;
/*!40000 ALTER TABLE `blogs` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `blogs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `brands`
--

DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `brands` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `name_ar` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `media_id` bigint(20) unsigned DEFAULT NULL,
  `shop_id` bigint(20) unsigned DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `brands_media_id_foreign` (`media_id`),
  KEY `brands_shop_id_foreign` (`shop_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brands`
--

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `brands` VALUES
(1,'Janmitram',NULL,NULL,1,1,0,'2026-08-03 11:17:28','2026-08-03 11:17:28');
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `cart_access_tokens`
--

DROP TABLE IF EXISTS `cart_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `access_token` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cart_access_tokens_customer_id_foreign` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_access_tokens`
--

LOCK TABLES `cart_access_tokens` WRITE;
/*!40000 ALTER TABLE `cart_access_tokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `cart_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `carts`
--

DROP TABLE IF EXISTS `carts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `carts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `access_token` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `shop_id` bigint(20) unsigned DEFAULT NULL,
  `is_buy_now` tinyint(1) NOT NULL DEFAULT '0',
  `quantity` int(11) NOT NULL DEFAULT '1',
  `color` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `size` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `carts_customer_id_foreign` (`customer_id`),
  KEY `carts_product_id_foreign` (`product_id`),
  KEY `carts_shop_id_foreign` (`shop_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carts`
--

LOCK TABLES `carts` WRITE;
/*!40000 ALTER TABLE `carts` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `carts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `name_ar` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(191) COLLATE utf8_unicode_ci DEFAULT 'other',
  `media_id` bigint(20) unsigned DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categories_media_id_foreign` (`media_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `categories` VALUES
(1,'Grocery',NULL,'other',3,'Grocery and Spices',1,'2026-08-03 11:11:55','2026-08-03 11:11:55');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `category_subcategories`
--

DROP TABLE IF EXISTS `category_subcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `category_subcategories` (
  `category_id` bigint(20) unsigned NOT NULL,
  `sub_category_id` bigint(20) unsigned NOT NULL,
  KEY `category_subcategories_category_id_foreign` (`category_id`),
  KEY `category_subcategories_sub_category_id_foreign` (`sub_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_subcategories`
--

LOCK TABLES `category_subcategories` WRITE;
/*!40000 ALTER TABLE `category_subcategories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `category_subcategories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `colors`
--

DROP TABLE IF EXISTS `colors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `colors` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `name_ar` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `shop_id` bigint(20) unsigned NOT NULL,
  `color_code` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `colors_shop_id_foreign` (`shop_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `colors`
--

LOCK TABLES `colors` WRITE;
/*!40000 ALTER TABLE `colors` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `colors` VALUES
(1,'yellow',NULL,1,'#fbe80e',1,'2026-08-03 11:17:17','2026-08-03 11:17:17');
/*!40000 ALTER TABLE `colors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `contact_us`
--

DROP TABLE IF EXISTS `contact_us`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_us` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `phone` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `whatsapp` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `messenger` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_us`
--

LOCK TABLES `contact_us` WRITE;
/*!40000 ALTER TABLE `contact_us` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `contact_us` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `countries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `numeric_code` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone_code` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `capital` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `currency` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `currency_name` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `currency_symbol` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `native` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `region` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitude` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitude` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `emoji` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `emojiU` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=226 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `countries` VALUES
(1,'Afghanistan','004','93','Kabul','AFN','Afghan afghani','؋','افغانستان','Asia','-74.65000000','4.48000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(2,'Antigua and Barbuda','028','1','St. John\'s','XCD','Eastern Caribbean dollar','$','Antigua and Barbuda','Americas','17.05000000','-61.80000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(3,'Argentina','032','54','Buenos Aires','ARS','Argentine peso','$','Argentina','Americas','-34.00000000','-64.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(4,'Armenia','051','374','Yerevan','AMD','Armenian dram','֏','Հայաստան','Asia','40.00000000','45.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(5,'Aruba','533','297','Oranjestad','AWG','Aruban florin','ƒ','Aruba','Americas','12.50000000','-69.96666666',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(6,'Australia','036','61','Canberra','AUD','Australian dollar','$','Australia','Oceania','-27.00000000','133.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(7,'Austria','040','43','Vienna','EUR','Euro','€','Österreich','Europe','47.33333333','13.33333333',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(8,'Azerbaijan','031','994','Baku','AZN','Azerbaijani manat','m','Azərbaycan','Asia','40.50000000','47.50000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(9,'Bahrain','048','973','Manama','BHD','Bahraini dinar','.د.ب','‏البحرين','Asia','26.00000000','50.55000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(10,'Bangladesh','050','880','Dhaka','BDT','Bangladeshi taka','৳','Bangladesh','Asia','24.00000000','90.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(11,'Barbados','052','1','Bridgetown','BBD','Barbadian dollar','Bds$','Barbados','Americas','13.16666666','-59.53333333',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(12,'Belarus','112','375','Minsk','BYN','Belarusian ruble','Br','Белару́сь','Europe','53.00000000','28.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(13,'Belgium','056','32','Brussels','EUR','Euro','€','België','Europe','50.83333333','4.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(14,'Belize','084','501','Belmopan','BZD','Belize dollar','$','Belize','Americas','17.25000000','-88.75000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(15,'Benin','204','229','Porto-Novo','XOF','West African CFA franc','CFA','Bénin','Africa','9.50000000','2.25000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(16,'Bermuda','060','1','Hamilton','BMD','Bermudian dollar','$','Bermuda','Americas','32.33333333','-64.75000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(17,'Bhutan','064','975','Thimphu','BTN','Bhutanese ngultrum','Nu.','ʼbrug-yul','Asia','27.50000000','90.50000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(18,'Bolivia','068','591','Sucre','BOB','Bolivian boliviano','Bs.','Bolivia','Americas','-10.00000000','-55.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(19,'British Indian Ocean Territory','086','246','Diego Garcia','USD','United States dollar','$','British Indian Ocean Territory','Africa','60.00000000','-95.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(20,'Cape Verde','132','238','Praia','CVE','Cape Verdean escudo','$','Cabo Verde','Africa','-30.00000000','-71.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(21,'China','156','86','Beijing','CNY','Chinese yuan','¥','中国','Asia','35.00000000','105.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(22,'Christmas Island','162','61','Flying Fish Cove','AUD','Australian dollar','$','Christmas Island','Oceania','-10.50000000','105.66666666',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(23,'Cocos (Keeling) Islands','166','61','West Island','AUD','Australian dollar','$','Cocos (Keeling) Islands','Oceania','-12.50000000','96.83333333',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(24,'Colombia','170','57','Bogotá','COP','Colombian peso','$','Colombia','Americas','4.00000000','-72.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(25,'Comoros','174','269','Moroni','KMF','Comorian franc','CF','Komori','Africa','-12.16666666','44.25000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(26,'Congo','178','242','Brazzaville','XAF','Central African CFA franc','FC','République du Congo','Africa','-1.00000000','15.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(27,'Cook Islands','184','682','Avarua','NZD','Cook Islands dollar','$','Cook Islands','Oceania','-21.23333333','-159.76666666',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(28,'Costa Rica','188','506','San Jose','CRC','Costa Rican colón','₡','Costa Rica','Americas','10.00000000','-84.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(29,'Cote D\'Ivoire (Ivory Coast)','384','225','Yamoussoukro','XOF','West African CFA franc','CFA',NULL,'Africa','8.00000000','-5.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(30,'Croatia','191','385','Zagreb','HRK','Croatian kuna','kn','Hrvatska','Europe','45.16666666','15.50000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(31,'Cuba','192','53','Havana','CUP','Cuban peso','$','Cuba','Americas','21.50000000','-80.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(32,'Curaçao','531','599','Willemstad','ANG','Netherlands Antillean guilder','ƒ','Curaçao','Americas','12.11666700','-68.93333300',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(33,'Cyprus','196','357','Nicosia','EUR','Euro','€','Κύπρος','Europe','35.00000000','33.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(34,'Czech Republic','203','420','Prague','CZK','Czech koruna','Kč','Česká republika','Europe','49.75000000','15.50000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(35,'Democratic Republic of the Congo','180','243','Kinshasa','CDF','Congolese Franc','FC','République démocratique du Congo','Africa','0.00000000','25.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(36,'Denmark','208','45','Copenhagen','DKK','Danish krone','Kr.','Danmark','Europe','56.00000000','10.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(37,'Djibouti','262','253','Djibouti','DJF','Djiboutian franc','Fdj','Djibouti','Africa','11.50000000','43.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(38,'Dominica','212','1','Roseau','XCD','Eastern Caribbean dollar','$','Dominica','Americas','15.41666666','-61.33333333',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(39,'Dominican Republic','214','1','Santo Domingo','DOP','Dominican peso','$','República Dominicana','Americas','19.00000000','-70.66666666',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(40,'Ecuador','218','593','Quito','USD','United States dollar','$','Ecuador','Americas','-2.00000000','-77.50000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(41,'Egypt','818','20','Cairo','EGP','Egyptian pound','ج.م','مصر‎','Africa','27.00000000','30.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(42,'El Salvador','222','503','San Salvador','USD','United States dollar','$','El Salvador','Americas','13.83333333','-88.91666666',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(43,'Equatorial Guinea','226','240','Malabo','XAF','Central African CFA franc','FCFA','Guinea Ecuatorial','Africa','2.00000000','10.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(44,'Eritrea','232','291','Asmara','ERN','Eritrean nakfa','Nfk','ኤርትራ','Africa','15.00000000','39.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(45,'Estonia','233','372','Tallinn','EUR','Euro','€','Eesti','Europe','59.00000000','26.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(46,'Eswatini','748','268','Mbabane','SZL','Lilangeni','E','Swaziland','Africa','-26.50000000','31.50000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(47,'Ethiopia','231','251','Addis Ababa','ETB','Ethiopian birr','Nkf','ኢትዮጵያ','Africa','8.00000000','38.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(48,'Falkland Islands','238','500','Stanley','FKP','Falkland Islands pound','£','Falkland Islands','Americas','-51.75000000','-59.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(49,'Faroe Islands','234','298','Torshavn','DKK','Danish krone','Kr.','Føroyar','Europe','62.00000000','-7.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(50,'Fiji Islands','242','679','Suva','FJD','Fijian dollar','FJ$','Fiji','Oceania','-18.00000000','175.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(51,'Finland','246','358','Helsinki','EUR','Euro','€','Suomi','Europe','64.00000000','26.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(52,'France','250','33','Paris','EUR','Euro','€','France','Europe','46.00000000','2.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(53,'French Guiana','254','594','Cayenne','EUR','Euro','€','Guyane française','Americas','4.00000000','-53.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(54,'French Polynesia','258','689','Papeete','XPF','CFP franc','₣','Polynésie française','Oceania','-15.00000000','-140.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(55,'French Southern Territories','260','262','Port-aux-Francais','EUR','Euro','€','Territoire des Terres australes et antarctiques fr','Africa','-49.25000000','69.16700000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(56,'Gabon','266','241','Libreville','XAF','Central African CFA franc','FCFA','Gabon','Africa','-1.00000000','11.75000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(57,'Georgia','268','995','Tbilisi','GEL','Georgian lari','ლ','საქართველო','Asia','42.00000000','43.50000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(58,'Germany','276','49','Berlin','EUR','Euro','€','Deutschland','Europe','51.00000000','9.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(59,'Ghana','288','233','Accra','GHS','Ghanaian cedi','GH₵','Ghana','Africa','8.00000000','-2.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(60,'Gibraltar','292','350','Gibraltar','GIP','Gibraltar pound','£','Gibraltar','Europe','36.13333333','-5.35000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(61,'Greece','300','30','Athens','EUR','Euro','€','Ελλάδα','Europe','39.00000000','22.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(62,'Greenland','304','299','Nuuk','DKK','Danish krone','Kr.','Kalaallit Nunaat','Americas','72.00000000','-40.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(63,'Grenada','308','1','St. George\'s','XCD','Eastern Caribbean dollar','$','Grenada','Americas','12.11666666','-61.66666666',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(64,'Guadeloupe','312','590','Basse-Terre','EUR','Euro','€','Guadeloupe','Americas','16.25000000','-61.58333300',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(65,'Guam','316','1','Hagatna','USD','US Dollar','$','Guam','Oceania','13.46666666','144.78333333',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(66,'Guatemala','320','502','Guatemala City','GTQ','Guatemalan quetzal','Q','Guatemala','Americas','15.50000000','-90.25000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(67,'Guernsey and Alderney','831','44','St Peter Port','GBP','British pound','£','Guernsey','Europe','49.46666666','-2.58333333',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(68,'Guinea','324','224','Conakry','GNF','Guinean franc','FG','Guinée','Africa','11.00000000','-10.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(69,'Guinea-Bissau','624','245','Bissau','XOF','West African CFA franc','CFA','Guiné-Bissau','Africa','12.00000000','-15.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(70,'Guyana','328','592','Georgetown','GYD','Guyanese dollar','$','Guyana','Americas','5.00000000','-59.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(71,'Haiti','332','509','Port-au-Prince','HTG','Haitian gourde','G','Haïti','Americas','19.00000000','-72.41666666',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(72,'Heard Island and McDonald Islands','334','672','','AUD','Australian dollar','$','Heard Island and McDonald Islands','','-53.10000000','72.51666666',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(73,'Honduras','340','504','Tegucigalpa','HNL','Honduran lempira','L','Honduras','Americas','15.00000000','-86.50000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(74,'Hong Kong S.A.R.','344','852','Hong Kong','HKD','Hong Kong dollar','$','香港','Asia','22.25000000','114.16666666',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(75,'Hungary','348','36','Budapest','HUF','Hungarian forint','Ft','Magyarország','Europe','47.00000000','20.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(76,'Iceland','352','354','Reykjavik','ISK','Icelandic króna','kr','Ísland','Europe','65.00000000','-18.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(77,'India','356','91','New Delhi','INR','Indian rupee','₹','भारत','Asia','20.00000000','77.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(78,'Indonesia','360','62','Jakarta','IDR','Indonesian rupiah','Rp','Indonesia','Asia','-5.00000000','120.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(79,'Iran','364','98','Tehran','IRR','Iranian rial','﷼','ایران','Asia','32.00000000','53.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(80,'Iraq','368','964','Baghdad','IQD','Iraqi dinar','د.ع','العراق','Asia','33.00000000','44.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(81,'Ireland','372','353','Dublin','EUR','Euro','€','Éire','Europe','53.00000000','-8.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(82,'Israel','376','972','Jerusalem','ILS','Israeli new shekel','₪','יִשְׂרָאֵל','Asia','31.50000000','34.75000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(83,'Italy','380','39','Rome','EUR','Euro','€','Italia','Europe','42.83333333','12.83333333',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(84,'Jamaica','388','1','Kingston','JMD','Jamaican dollar','J$','Jamaica','Americas','18.25000000','-77.50000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(85,'Japan','392','81','Tokyo','JPY','Japanese yen','¥','日本','Asia','36.00000000','138.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(86,'Jersey','832','44','Saint Helier','GBP','British pound','£','Jersey','Europe','49.25000000','-2.16666666',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(87,'Jordan','400','962','Amman','JOD','Jordanian dinar','ا.د','الأردن','Asia','31.00000000','36.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(88,'Kazakhstan','398','7','Astana','KZT','Kazakhstani tenge','лв','Қазақстан','Asia','48.00000000','68.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(89,'Kenya','404','254','Nairobi','KES','Kenyan shilling','KSh','Kenya','Africa','1.00000000','38.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(90,'Kiribati','296','686','Tarawa','AUD','Australian dollar','$','Kiribati','Oceania','1.41666666','173.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(91,'Kosovo','926','383','Pristina','EUR','Euro','€','Republika e Kosovës','Europe','29.50000000','45.75000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(92,'Kyrgyzstan','417','996','Bishkek','KGS','Kyrgyzstani som','лв','Кыргызстан','Asia','41.00000000','75.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(93,'Laos','418','856','Vientiane','LAK','Lao kip','₭','ສປປລາວ','Asia','18.00000000','105.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(94,'Latvia','428','371','Riga','EUR','Euro','€','Latvija','Europe','57.00000000','25.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(95,'Lebanon','422','961','Beirut','LBP','Lebanese pound','£','لبنان','Asia','33.83333333','35.83333333',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(96,'Lesotho','426','266','Maseru','LSL','Lesotho loti','L','Lesotho','Africa','-29.50000000','28.50000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(97,'Liberia','430','231','Monrovia','LRD','Liberian dollar','$','Liberia','Africa','6.50000000','-9.50000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(98,'Libya','434','218','Tripolis','LYD','Libyan dinar','د.ل','‏ليبيا','Africa','25.00000000','17.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(99,'Liechtenstein','438','423','Vaduz','CHF','Swiss franc','CHf','Liechtenstein','Europe','47.26666666','9.53333333',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(100,'Lithuania','440','370','Vilnius','EUR','Euro','€','Lietuva','Europe','56.00000000','24.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(101,'Luxembourg','442','352','Luxembourg','EUR','Euro','€','Luxembourg','Europe','49.75000000','6.16666666',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(102,'Macau S.A.R.','446','853','Macao','MOP','Macanese pataca','$','澳門','Asia','22.16666666','113.55000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(103,'Madagascar','450','261','Antananarivo','MGA','Malagasy ariary','Ar','Madagasikara','Africa','-20.00000000','47.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(104,'Malawi','454','265','Lilongwe','MWK','Malawian kwacha','MK','Malawi','Africa','-13.50000000','34.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(105,'Malaysia','458','60','Kuala Lumpur','MYR','Malaysian ringgit','RM','Malaysia','Asia','2.50000000','112.50000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(106,'Maldives','462','960','Male','MVR','Maldivian rufiyaa','Rf','Maldives','Asia','3.25000000','73.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(107,'Mali','466','223','Bamako','XOF','West African CFA franc','CFA','Mali','Africa','17.00000000','-4.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(108,'Malta','470','356','Valletta','EUR','Euro','€','Malta','Europe','35.83333333','14.58333333',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(109,'Man (Isle of)','833','44','Douglas, Isle of Man','GBP','British pound','£','Isle of Man','Europe','54.25000000','-4.50000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(110,'Marshall Islands','584','692','Majuro','USD','United States dollar','$','M̧ajeļ','Oceania','9.00000000','168.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(111,'Martinique','474','596','Fort-de-France','EUR','Euro','€','Martinique','Americas','14.66666700','-61.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(112,'Mauritania','478','222','Nouakchott','MRO','Mauritanian ouguiya','MRU','موريتانيا','Africa','20.00000000','-12.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(113,'Mauritius','480','230','Port Louis','MUR','Mauritian rupee','₨','Maurice','Africa','-20.28333333','57.55000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(114,'Mayotte','175','262','Mamoudzou','EUR','Euro','€','Mayotte','Africa','-12.83333333','45.16666666',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(115,'Mexico','484','52','Ciudad de México','MXN','Mexican peso','$','México','Americas','23.00000000','-102.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(116,'Micronesia','583','691','Palikir','USD','United States dollar','$','Micronesia','Oceania','6.91666666','158.25000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(117,'Moldova','498','373','Chisinau','MDL','Moldovan leu','L','Moldova','Europe','47.00000000','29.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(118,'Monaco','492','377','Monaco','EUR','Euro','€','Monaco','Europe','43.73333333','7.40000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(119,'Mongolia','496','976','Ulan Bator','MNT','Mongolian tögrög','₮','Монгол улс','Asia','46.00000000','105.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(120,'Montenegro','499','382','Podgorica','EUR','Euro','€','Црна Гора','Europe','42.50000000','19.30000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(121,'Montserrat','500','1','Plymouth','XCD','Eastern Caribbean dollar','$','Montserrat','Americas','16.75000000','-62.20000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(122,'Morocco','504','212','Rabat','MAD','Moroccan dirham','DH','المغرب','Africa','32.00000000','-5.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(123,'Mozambique','508','258','Maputo','MZN','Mozambican metical','MT','Moçambique','Africa','-18.25000000','35.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(124,'Myanmar','104','95','Nay Pyi Taw','MMK','Burmese kyat','K','မြန်မာ','Asia','22.00000000','98.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(125,'Namibia','516','264','Windhoek','NAD','Namibian dollar','$','Namibia','Africa','-22.00000000','17.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(126,'Nauru','520','674','Yaren','AUD','Australian dollar','$','Nauru','Oceania','-0.53333333','166.91666666',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(127,'Nepal','524','977','Kathmandu','NPR','Nepalese rupee','₨','नपल','Asia','28.00000000','84.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(128,'Netherlands','528','31','Amsterdam','EUR','Euro','€','Nederland','Europe','52.50000000','5.75000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(129,'New Caledonia','540','687','Noumea','XPF','CFP franc','₣','Nouvelle-Calédonie','Oceania','-21.50000000','165.50000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(130,'New Zealand','554','64','Wellington','NZD','New Zealand dollar','$','New Zealand','Oceania','-41.00000000','174.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(131,'Nicaragua','558','505','Managua','NIO','Nicaraguan córdoba','C$','Nicaragua','Americas','13.00000000','-85.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(132,'Niger','562','227','Niamey','XOF','West African CFA franc','CFA','Niger','Africa','16.00000000','8.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(133,'Nigeria','566','234','Abuja','NGN','Nigerian naira','₦','Nigeria','Africa','10.00000000','8.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(134,'Niue','570','683','Alofi','NZD','New Zealand dollar','$','Niuē','Oceania','-19.03333333','-169.86666666',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(135,'Norfolk Island','574','672','Kingston','AUD','Australian dollar','$','Norfolk Island','Oceania','-29.03333333','167.95000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(136,'North Korea','408','850','Pyongyang','KPW','North Korean Won','₩','북한','Asia','40.00000000','127.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(137,'North Macedonia','807','389','Skopje','MKD','Denar','ден','Северна Македонија','Europe','41.83333333','22.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(138,'Northern Mariana Islands','580','1','Saipan','USD','United States dollar','$','Northern Mariana Islands','Oceania','15.20000000','145.75000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(139,'Norway','578','47','Oslo','NOK','Norwegian krone','kr','Norge','Europe','62.00000000','10.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(140,'Oman','512','968','Muscat','OMR','Omani rial','.ع.ر','عمان','Asia','21.00000000','57.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(141,'Pakistan','586','92','Islamabad','PKR','Pakistani rupee','₨','Pakistan','Asia','30.00000000','70.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(142,'Palau','585','680','Melekeok','USD','United States dollar','$','Palau','Oceania','7.50000000','134.50000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(143,'Palestinian Territory Occupied','275','970','East Jerusalem','ILS','Israeli new shekel','₪','فلسطين','Asia','31.90000000','35.20000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(144,'Panama','591','507','Panama City','PAB','Panamanian balboa','B/.','Panamá','Americas','9.00000000','-80.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(145,'Papua New Guinea','598','675','Port Moresby','PGK','Papua New Guinean kina','K','Papua Niugini','Oceania','-6.00000000','147.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(146,'Paraguay','600','595','Asuncion','PYG','Paraguayan guarani','₲','Paraguay','Americas','-23.00000000','-58.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(147,'Peru','604','51','Lima','PEN','Peruvian sol','S/.','Perú','Americas','-10.00000000','-76.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(148,'Philippines','608','63','Manila','PHP','Philippine peso','₱','Pilipinas','Asia','13.00000000','122.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(149,'Pitcairn Island','612','870','Adamstown','NZD','New Zealand dollar','$','Pitcairn Islands','Oceania','-25.06666666','-130.10000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(150,'Poland','616','48','Warsaw','PLN','Polish złoty','zł','Polska','Europe','52.00000000','20.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(151,'Portugal','620','351','Lisbon','EUR','Euro','€','Portugal','Europe','39.50000000','-8.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(152,'Puerto Rico','630','1','San Juan','USD','United States dollar','$','Puerto Rico','Americas','18.25000000','-66.50000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(153,'Qatar','634','974','Doha','QAR','Qatari riyal','ق.ر','قطر','Asia','25.50000000','51.25000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(154,'Reunion','638','262','Saint-Denis','EUR','Euro','€','La Réunion','Africa','-21.15000000','55.50000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(155,'Romania','642','40','Bucharest','RON','Romanian leu','lei','România','Europe','46.00000000','25.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(156,'Russia','643','7','Moscow','RUB','Russian ruble','₽','Россия','Europe','60.00000000','100.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(157,'Rwanda','646','250','Kigali','RWF','Rwandan franc','FRw','Rwanda','Africa','-2.00000000','30.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(158,'Saint Helena','654','290','Jamestown','SHP','Saint Helena pound','£','Saint Helena','Africa','-15.95000000','-5.70000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(159,'Saint Kitts and Nevis','659','1','Basseterre','XCD','Eastern Caribbean dollar','$','Saint Kitts and Nevis','Americas','17.33333333','-62.75000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(160,'Saint Lucia','662','1','Castries','XCD','Eastern Caribbean dollar','$','Saint Lucia','Americas','13.88333333','-60.96666666',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(161,'Saint Pierre and Miquelon','666','508','Saint-Pierre','EUR','Euro','€','Saint-Pierre-et-Miquelon','Americas','46.83333333','-56.33333333',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(162,'Saint Vincent and the Grenadines','670','1','Kingstown','XCD','Eastern Caribbean dollar','$','Saint Vincent and the Grenadines','Americas','13.25000000','-61.20000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(163,'Saint-Barthelemy','652','590','Gustavia','EUR','Euro','€','Saint-Barthélemy','Americas','18.50000000','-63.41666666',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(164,'Saint-Martin (French part)','663','590','Marigot','EUR','Euro','€','Saint-Martin','Americas','18.08333333','-63.95000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(165,'Samoa','882','685','Apia','WST','Samoan tālā','SAT','Samoa','Oceania','-13.58333333','-172.33333333',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(166,'San Marino','674','378','San Marino','EUR','Euro','€','San Marino','Europe','43.76666666','12.41666666',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(167,'Sao Tome and Principe','678','239','Sao Tome','STD','Dobra','Db','São Tomé e Príncipe','Africa','1.00000000','7.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(168,'Saudi Arabia','682','966','Riyadh','SAR','Saudi riyal','﷼','المملكة العربية السعودية','Asia','25.00000000','45.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(169,'Senegal','686','221','Dakar','XOF','West African CFA franc','CFA','Sénégal','Africa','14.00000000','-14.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(170,'Serbia','688','381','Belgrade','RSD','Serbian dinar','din','Србија','Europe','44.00000000','21.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(171,'Seychelles','690','248','Victoria','SCR','Seychellois rupee','SRe','Seychelles','Africa','-4.58333333','55.66666666',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(172,'Sierra Leone','694','232','Freetown','SLL','Sierra Leonean leone','Le','Sierra Leone','Africa','8.50000000','-11.50000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(173,'Singapore','702','65','Singapur','SGD','Singapore dollar','$','Singapore','Asia','1.36666666','103.80000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(174,'Sint Maarten (Dutch part)','534','1721','Philipsburg','ANG','Netherlands Antillean guilder','ƒ','Sint Maarten','Americas','18.03333300','-63.05000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(175,'Slovakia','703','421','Bratislava','EUR','Euro','€','Slovensko','Europe','48.66666666','19.50000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(176,'Slovenia','705','386','Ljubljana','EUR','Euro','€','Slovenija','Europe','46.11666666','14.81666666',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(177,'Solomon Islands','090','677','Honiara','SBD','Solomon Islands dollar','Si$','Solomon Islands','Oceania','-8.00000000','159.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(178,'Somalia','706','252','Mogadishu','SOS','Somali shilling','Sh.so.','Soomaaliya','Africa','10.00000000','49.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(179,'South Africa','710','27','Pretoria','ZAR','South African rand','R','South Africa','Africa','-29.00000000','24.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(180,'South Georgia','239','500','Grytviken','GBP','British pound','£','South Georgia','Americas','-54.50000000','-37.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(181,'South Korea','410','82','Seoul','KRW','Won','₩','대한민국','Asia','37.00000000','127.50000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(182,'South Sudan','728','211','Juba','SSP','South Sudanese pound','£','South Sudan','Africa','7.00000000','30.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(183,'Spain','724','34','Madrid','EUR','Euro','€','España','Europe','40.00000000','-4.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(184,'Sri Lanka','144','94','Colombo','LKR','Sri Lankan rupee','Rs','śrī laṃkāva','Asia','7.00000000','81.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(185,'Sudan','729','249','Khartoum','SDG','Sudanese pound','.س.ج','السودان','Africa','15.00000000','30.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(186,'Suriname','740','597','Paramaribo','SRD','Surinamese dollar','$','Suriname','Americas','4.00000000','-56.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(187,'Svalbard and Jan Mayen Islands','744','47','Longyearbyen','NOK','Norwegian Krone','kr','Svalbard og Jan Mayen','Europe','78.00000000','20.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(188,'Sweden','752','46','Stockholm','SEK','Swedish krona','kr','Sverige','Europe','62.00000000','15.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(189,'Switzerland','756','41','Bern','CHF','Swiss franc','CHf','Schweiz','Europe','47.00000000','8.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(190,'Syria','760','963','Damascus','SYP','Syrian pound','LS','سوريا','Asia','35.00000000','38.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(191,'Taiwan','158','886','Taipei','TWD','New Taiwan dollar','$','臺灣','Asia','23.50000000','121.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(192,'Tajikistan','762','992','Dushanbe','TJS','Tajikistani somoni','SM','Тоҷикистон','Asia','39.00000000','71.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(193,'Tanzania','834','255','Dodoma','TZS','Tanzanian shilling','TSh','Tanzania','Africa','-6.00000000','35.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(194,'Thailand','764','66','Bangkok','THB','Thai baht','฿','ประเทศไทย','Asia','15.00000000','100.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(195,'The Bahamas','044','1','Nassau','BSD','Bahamian dollar','B$','Bahamas','Americas','24.25000000','-76.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(196,'The Gambia ','270','220','Banjul','GMD','Gambian dalasi','D','Gambia','Africa','13.46666666','-16.56666666',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(197,'Timor-Leste','626','670','Dili','USD','United States dollar','$','Timor-Leste','Asia','-8.83333333','125.91666666',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(198,'Togo','768','228','Lome','XOF','West African CFA franc','CFA','Togo','Africa','8.00000000','1.16666666',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(199,'Tokelau','772','690','','NZD','New Zealand dollar','$','Tokelau','Oceania','-9.00000000','-172.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(200,'Tonga','776','676','Nuku\'alofa','TOP','Tongan paʻanga','$','Tonga','Oceania','-20.00000000','-175.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(201,'Trinidad and Tobago','780','1','Port of Spain','TTD','Trinidad and Tobago dollar','$','Trinidad and Tobago','Americas','11.00000000','-61.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(202,'Tunisia','788','216','Tunis','TND','Tunisian dinar','ت.د','تونس','Africa','34.00000000','9.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(203,'Turkey','792','90','Ankara','TRY','Turkish lira','₺','Türkiye','Asia','39.00000000','35.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(204,'Turkmenistan','795','993','Ashgabat','TMT','Turkmenistan manat','T','Türkmenistan','Asia','40.00000000','60.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(205,'Turks and Caicos Islands','796','1','Cockburn Town','USD','United States dollar','$','Turks and Caicos Islands','Americas','21.75000000','-71.58333333',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(206,'Tuvalu','798','688','Funafuti','AUD','Australian dollar','$','Tuvalu','Oceania','-8.00000000','178.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(207,'Uganda','800','256','Kampala','UGX','Ugandan shilling','USh','Uganda','Africa','1.00000000','32.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(208,'Ukraine','804','380','Kyiv','UAH','Ukrainian hryvnia','₴','Україна','Europe','49.00000000','32.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(209,'United Arab Emirates','784','971','Abu Dhabi','AED','United Arab Emirates dirham','إ.د','دولة الإمارات العربية المتحدة','Asia','24.00000000','54.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(210,'United Kingdom','826','44','London','GBP','British pound','£','United Kingdom','Europe','54.00000000','-2.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(211,'United States','840','1','Washington','USD','United States dollar','$','United States','Americas','38.00000000','-97.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(212,'United States Minor Outlying Islands','581','1','','USD','United States dollar','$','United States Minor Outlying Islands','Americas','0.00000000','0.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(213,'Uruguay','858','598','Montevideo','UYU','Uruguayan peso','$','Uruguay','Americas','-33.00000000','-56.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(214,'Uzbekistan','860','998','Tashkent','UZS','Uzbekistani soʻm','лв','O‘zbekiston','Asia','41.00000000','64.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(215,'Vanuatu','548','678','Port Vila','VUV','Vanuatu vatu','VT','Vanuatu','Oceania','-16.00000000','167.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(216,'Vatican City State (Holy See)','336','379','Vatican City','EUR','Euro','€','Vaticano','Europe','41.90000000','12.45000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(217,'Venezuela','862','58','Caracas','VES','Bolívar','Bs','Venezuela','Americas','8.00000000','-66.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(218,'Vietnam','704','84','Hanoi','VND','Vietnamese đồng','₫','Việt Nam','Asia','16.16666666','107.83333333',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(219,'Virgin Islands (British)','092','1','Road Town','USD','United States dollar','$','British Virgin Islands','Americas','18.43138300','-64.62305000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(220,'Virgin Islands (US)','850','1','Charlotte Amalie','USD','United States dollar','$','United States Virgin Islands','Americas','18.34000000','-64.93000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(221,'Wallis and Futuna Islands','876','681','Mata Utu','XPF','CFP franc','₣','Wallis et Futuna','Oceania','-13.30000000','-176.20000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(222,'Western Sahara','732','212','El-Aaiun','MAD','Moroccan Dirham','MAD','الصحراء الغربية','Africa','24.50000000','-13.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(223,'Yemen','887','967','Sanaa','YER','Yemeni rial','﷼','اليَمَن','Asia','15.00000000','48.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(224,'Zambia','894','260','Lusaka','ZMW','Zambian kwacha','ZK','Zambia','Africa','-15.00000000','30.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(225,'Zimbabwe','716','263','Harare','ZWL','Zimbabwe Dollar','$','Zimbabwe','Africa','-20.00000000','30.00000000',NULL,NULL,1,NULL,'2026-08-03 08:41:10','2026-08-03 08:41:10');
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `coupon_collects`
--

DROP TABLE IF EXISTS `coupon_collects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupon_collects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `coupon_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `coupon_collects_coupon_id_foreign` (`coupon_id`),
  KEY `coupon_collects_user_id_foreign` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupon_collects`
--

LOCK TABLES `coupon_collects` WRITE;
/*!40000 ALTER TABLE `coupon_collects` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `coupon_collects` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupons` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `shop_id` bigint(20) unsigned DEFAULT NULL,
  `type` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `discount` double NOT NULL,
  `min_amount` double NOT NULL,
  `started_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `expired_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `limit_for_user` int(11) DEFAULT '10',
  `max_discount_amount` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `coupons_shop_id_foreign` (`shop_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons`
--

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `currencies`
--

DROP TABLE IF EXISTS `currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `currencies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `symbol` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `rate` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currencies`
--

LOCK TABLES `currencies` WRITE;
/*!40000 ALTER TABLE `currencies` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `currencies` VALUES
(1,'INR',NULL,'₹','1',1,1,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(2,'USD',NULL,'$','1',1,0,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(3,'EUR',NULL,'€','1',1,0,'2026-08-03 08:41:09','2026-08-03 08:41:09');
/*!40000 ALTER TABLE `currencies` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customers_user_id_foreign` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `delivery_charges`
--

DROP TABLE IF EXISTS `delivery_charges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `delivery_charges` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `min_qty` int(11) DEFAULT NULL,
  `max_qty` int(11) DEFAULT NULL,
  `charge` double NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_charges`
--

LOCK TABLES `delivery_charges` WRITE;
/*!40000 ALTER TABLE `delivery_charges` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `delivery_charges` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `device_keys`
--

DROP TABLE IF EXISTS `device_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_keys` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `key` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `device_type` varchar(191) COLLATE utf8_unicode_ci DEFAULT 'android',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `device_keys_user_id_foreign` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_keys`
--

LOCK TABLES `device_keys` WRITE;
/*!40000 ALTER TABLE `device_keys` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `device_keys` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `driver_locations`
--

DROP TABLE IF EXISTS `driver_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `driver_locations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `driver_id` bigint(20) unsigned NOT NULL,
  `latitude` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitude` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `driver_locations_driver_id_foreign` (`driver_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `driver_locations`
--

LOCK TABLES `driver_locations` WRITE;
/*!40000 ALTER TABLE `driver_locations` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `driver_locations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `driver_orders`
--

DROP TABLE IF EXISTS `driver_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `driver_orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `driver_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL,
  `is_completed` tinyint(1) NOT NULL DEFAULT '0',
  `assign_for` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_accept` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cash_collect` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `driver_orders_driver_id_foreign` (`driver_id`),
  KEY `driver_orders_order_id_foreign` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `driver_orders`
--

LOCK TABLES `driver_orders` WRITE;
/*!40000 ALTER TABLE `driver_orders` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `driver_orders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `drivers`
--

DROP TABLE IF EXISTS `drivers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `drivers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `total_cash_collected` double NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `drivers_user_id_foreign` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drivers`
--

LOCK TABLES `drivers` WRITE;
/*!40000 ALTER TABLE `drivers` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `drivers` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `connection` text COLLATE utf8_unicode_ci NOT NULL,
  `queue` text COLLATE utf8_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `favorites`
--

DROP TABLE IF EXISTS `favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `favorites` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `favorites_customer_id_foreign` (`customer_id`),
  KEY `favorites_product_id_foreign` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favorites`
--

LOCK TABLES `favorites` WRITE;
/*!40000 ALTER TABLE `favorites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `favorites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `flash_sale_products`
--

DROP TABLE IF EXISTS `flash_sale_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `flash_sale_products` (
  `flash_sale_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `price` double DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `sale_quantity` int(11) DEFAULT '0',
  KEY `flash_sale_products_flash_sale_id_foreign` (`flash_sale_id`),
  KEY `flash_sale_products_product_id_foreign` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flash_sale_products`
--

LOCK TABLES `flash_sale_products` WRITE;
/*!40000 ALTER TABLE `flash_sale_products` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `flash_sale_products` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `flash_sales`
--

DROP TABLE IF EXISTS `flash_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `flash_sales` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `start_time` time NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_time` time NOT NULL,
  `end_date` date DEFAULT NULL,
  `discount` double NOT NULL DEFAULT '0',
  `min_discount` double DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `description` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `media_id` bigint(20) unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `flash_sales_media_id_foreign` (`media_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flash_sales`
--

LOCK TABLES `flash_sales` WRITE;
/*!40000 ALTER TABLE `flash_sales` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `flash_sales` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `footer_items`
--

DROP TABLE IF EXISTS `footer_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `footer_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `footer_id` bigint(20) unsigned NOT NULL,
  `type` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'link',
  `title` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ar_title` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `shop_type` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'single',
  `target` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT '_self',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `order` int(11) NOT NULL DEFAULT '0',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `footer_items_footer_id_foreign` (`footer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `footer_items`
--

LOCK TABLES `footer_items` WRITE;
/*!40000 ALTER TABLE `footer_items` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `footer_items` VALUES
(1,1,'logo',NULL,NULL,NULL,'single','_self',1,0,1,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(2,1,'text','The ultimate all-in-one solution for your eCommerce business worldwide.','الحل الأمثل الشامل لأعمال التجارة الإلكترونية الخاصة بك في جميع أنحاء العالم',NULL,'single','_self',1,1,1,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(3,1,'phone','+880123456789','+880123456789',NULL,'single','_self',1,2,1,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(4,1,'email','admin@example.com','admin@example.com',NULL,'single','_self',1,3,1,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(5,1,'social_links',NULL,NULL,NULL,'single','_self',1,4,1,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(6,2,'link','Products','المنتجات','/products','single','_self',1,0,0,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(7,2,'link','Most Popular','الاكثر شعبية','/most-popular','single','_self',1,1,0,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(8,2,'link','Best Deal','الافضل العرض','/best-deal','single','_self',1,2,0,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(9,2,'link','Become a Seller','صاحب متجر','/shop/register','multi','_blank',1,3,1,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(10,2,'link','Blogs','المدونات','/blogs','single','_self',1,5,0,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(11,2,'link','About us','من نحن','/about-us','single','_self',1,0,0,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(12,3,'link','Contact','اتصل بنا','/contact-us','single','_self',1,1,0,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(13,3,'link','Terms & Conditions','الشروط والاحكام','/terms-and-conditions','single','_self',1,2,0,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(14,3,'link','Privacy Policy','سياسة الخصوصية','/privacy-policy','single','_self',1,3,0,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(15,4,'app_store',NULL,NULL,NULL,'single','_self',1,0,1,'2026-08-03 08:41:10','2026-08-03 08:41:10');
/*!40000 ALTER TABLE `footer_items` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `footers`
--

DROP TABLE IF EXISTS `footers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `footers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ar_title` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `order` int(11) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `footers`
--

LOCK TABLES `footers` WRITE;
/*!40000 ALTER TABLE `footers` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `footers` VALUES
(1,NULL,NULL,NULL,0,1,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(2,'Quick Links','روابط سريعة',NULL,1,1,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(3,'Company','شركة',NULL,2,1,'2026-08-03 08:41:10','2026-08-03 08:41:10'),
(4,'Download our app','تحميل التطبيق',NULL,3,1,'2026-08-03 08:41:10','2026-08-03 08:41:10');
/*!40000 ALTER TABLE `footers` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `galleries`
--

DROP TABLE IF EXISTS `galleries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `galleries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `shop_id` bigint(20) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total_image` int(11) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `galleries_shop_id_foreign` (`shop_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `galleries`
--

LOCK TABLES `galleries` WRITE;
/*!40000 ALTER TABLE `galleries` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `galleries` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `generate_settings`
--

DROP TABLE IF EXISTS `generate_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `generate_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `logo_id` bigint(20) unsigned DEFAULT NULL,
  `favicon_id` bigint(20) unsigned DEFAULT NULL,
  `mobile` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `google_playstore_url` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `show_download_app` tinyint(1) NOT NULL DEFAULT '1',
  `app_store_url` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `currency` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `currency_id` bigint(20) unsigned DEFAULT NULL,
  `currency_position` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direction` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `show_footer` tinyint(1) NOT NULL DEFAULT '1',
  `footer_phone` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `footer_email` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `primary_color` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT '#8b5cf6',
  `secondary_color` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT '#ede9fe',
  `business_based_on` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'commission',
  `commission` double NOT NULL DEFAULT '10',
  `commission_type` varchar(191) COLLATE utf8_unicode_ci DEFAULT 'percentage',
  `commission_charge` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'per_order',
  `shop_pos` tinyint(1) NOT NULL DEFAULT '1',
  `shop_register` tinyint(1) NOT NULL DEFAULT '1',
  `shop_type` varchar(191) COLLATE utf8_unicode_ci DEFAULT 'multi' COMMENT 'multi, single',
  `new_product_approval` tinyint(1) NOT NULL DEFAULT '1',
  `update_product_approval` tinyint(1) NOT NULL DEFAULT '1',
  `min_withdraw` double DEFAULT NULL,
  `max_withdraw` double DEFAULT NULL,
  `withdraw_request` int(11) DEFAULT NULL,
  `footer_text` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `footer_description` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `footer_logo_id` bigint(20) unsigned DEFAULT NULL,
  `footer_qrcode_id` bigint(20) unsigned DEFAULT NULL,
  `app_logo_id` bigint(20) unsigned DEFAULT NULL,
  `show_sku` tinyint(1) NOT NULL DEFAULT '0',
  `default_delivery_charge` double NOT NULL DEFAULT '0',
  `cash_on_delivery` tinyint(1) NOT NULL DEFAULT '1',
  `online_payment` tinyint(1) NOT NULL DEFAULT '1',
  `return_order_within_days` int(11) DEFAULT '3',
  `product_description` text COLLATE utf8_unicode_ci,
  `page_description` text COLLATE utf8_unicode_ci,
  `blog_description` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `generate_settings_logo_id_foreign` (`logo_id`),
  KEY `generate_settings_favicon_id_foreign` (`favicon_id`),
  KEY `generate_settings_footer_logo_id_foreign` (`footer_logo_id`),
  KEY `generate_settings_footer_qrcode_id_foreign` (`footer_qrcode_id`),
  KEY `generate_settings_app_logo_id_foreign` (`app_logo_id`),
  KEY `generate_settings_currency_id_foreign` (`currency_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `generate_settings`
--

LOCK TABLES `generate_settings` WRITE;
/*!40000 ALTER TABLE `generate_settings` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `generate_settings` VALUES
(1,'Laravel','Laravel',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09','₹',1,'prefix','ltr',1,'+880123456789',NULL,'#ee456b','#fee5e8','commission',10,'percentage','per_order',1,1,'multi',1,1,NULL,NULL,NULL,'All right reserved by company','The ultimate all-in-one solution for your eCommerce business worldwide.',NULL,NULL,NULL,0,0,1,1,3,'Product name: {product_name}. Short description: {short_description}. Write a long, SEO-friendly product description that includes relevant keywords, highlights unique features, and encourages buyers to take action.','The page title is {title}. Generate a well-structured, professional, and legally appropriate long content for this page, ensuring it covers all important points relevant to {title}.','The blog title is {title}. Generate a well-structured, professional, and legally appropriate long content for this blog, ensuring it covers all important points relevant to {title}.');
/*!40000 ALTER TABLE `generate_settings` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `google_re_captchas`
--

DROP TABLE IF EXISTS `google_re_captchas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `google_re_captchas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `site_key` text COLLATE utf8_unicode_ci NOT NULL,
  `secret_key` text COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `google_re_captchas`
--

LOCK TABLES `google_re_captchas` WRITE;
/*!40000 ALTER TABLE `google_re_captchas` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `google_re_captchas` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `languages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `direction` varchar(191) COLLATE utf8_unicode_ci DEFAULT 'ltr',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `languages`
--

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `legal_pages`
--

DROP TABLE IF EXISTS `legal_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `legal_pages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `legal_pages`
--

LOCK TABLES `legal_pages` WRITE;
/*!40000 ALTER TABLE `legal_pages` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `legal_pages` VALUES
(1,'Privacy Policy','privacy-policy','<h2>Privacy Policy</h2><p>Your privacy is important to us. This policy outlines how we collect, use, and protect your personal information when you use our services.</p><p>We collect information you provide directly, such as your name, email address, phone number, and shipping address when you create an account or place an order.</p><p>We use your information to process orders, provide customer support, and improve our services. We do not share your personal information with third parties except as necessary to fulfill orders or as required by law.</p>','2026-08-03 08:41:09','2026-08-03 08:41:09'),
(2,'Terms of Service','terms-and-conditions','<h2>Terms of Service</h2><p>By using our platform, you agree to these terms and conditions. Please read them carefully.</p><p>All products and services are provided as described. We reserve the right to modify or discontinue any service without prior notice.</p><p>You are responsible for maintaining the confidentiality of your account and password. You agree to accept responsibility for all activities that occur under your account.</p>','2026-08-03 08:41:09','2026-08-03 08:41:09'),
(3,'Return policy / Refund Policy','return-and-refund-policy','<h2>Return & Refund Policy</h2><p>We accept returns within 30 days of delivery. Items must be unused and in original packaging.</p><p>Refunds will be processed within 5-7 business days after we receive the returned item. Shipping costs are non-refundable.</p><p>For digital products, all sales are final unless the product is defective or not as described.</p>','2026-08-03 08:41:09','2026-08-03 08:41:09'),
(4,'Shipping & Delivery Policy','shipping-and-delivery-policy','<h2>Shipping & Delivery Policy</h2><p>We offer free shipping on orders over a certain amount. Standard delivery takes 3-7 business days.</p><p>Express delivery is available at an additional cost. Delivery times may vary depending on your location.</p><p>We are not responsible for delays caused by customs, weather conditions, or other factors beyond our control.</p>','2026-08-03 08:41:09','2026-08-03 08:41:09'),
(5,'About Us','about-us','<h2>About Us</h2><p>Welcome to our marketplace! We are a leading e-commerce platform connecting buyers with trusted sellers.</p><p>Our mission is to provide a seamless shopping experience with quality products at competitive prices. We support local businesses and entrepreneurs.</p><p>With our multi-vendor platform, you can browse products from multiple shops, compare prices, and enjoy secure payments.</p>','2026-08-03 08:41:09','2026-08-03 08:41:09');
/*!40000 ALTER TABLE `legal_pages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `media` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(45) COLLATE utf8_unicode_ci DEFAULT 'image',
  `name` text COLLATE utf8_unicode_ci,
  `original_name` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `src` text COLLATE utf8_unicode_ci NOT NULL,
  `extention` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `media` VALUES
(1,'image','ab',NULL,'default/dummy-profile.png','png','2026-08-03 08:41:11','2026-08-03 08:41:11'),
(2,'image','doloremque',NULL,'default/dummy-profile.png','png','2026-08-03 08:41:11','2026-08-03 08:41:11'),
(3,'image','Spices-Icon.png',NULL,'categories/JEdwV1YWp2oA0HpmJJNXaUankY4CY6JgdvEqMoIe.png',NULL,'2026-08-03 11:11:55','2026-08-03 11:11:55'),
(4,'thumbnail','JanMitra_logoNew.png',NULL,'banners/39iLmbcav4gWnNF6o1AvU7hhQt4DaaZJMPDgyvGf.png',NULL,'2026-08-03 11:20:28','2026-08-03 11:20:28'),
(5,'thumbnail','actual_logo.png',NULL,'products/74Io38TeRfXkRiTJdX5VQ38WUlhaTVXDRdmUZo4D.png',NULL,'2026-08-03 11:23:39','2026-08-03 11:23:39'),
(6,'image','addclass.png',NULL,'users/profile/7US5FqfzIGwOe84ppZTIOwwcyX79gYV5Z9cWvE8u.png',NULL,'2026-08-03 11:44:52','2026-08-03 11:44:52'),
(7,'image','actual_logo.png',NULL,'shops/logo/u8JbMLLwmRobE0jPAEfHdH2SyylKYYcri0rBU0sN.png',NULL,'2026-08-03 11:44:54','2026-08-03 11:44:54'),
(8,'image','perfet2.png',NULL,'shops/banner/JmAOKNEB0mNq8vsDoDynHs6qnU1haFxfkH8PlumF.png',NULL,'2026-08-03 11:44:54','2026-08-03 11:44:54'),
(9,'image','actual_logo.png',NULL,'users/profile/enyNlWMiFFs3ksH9eeLUg2H5gJSOd7Q8ehe3YUID.png',NULL,'2026-08-03 11:48:49','2026-08-03 11:48:49'),
(10,'image','gym_db - public.png',NULL,'shops/logo/5S5ksyJzYHhvJwlb3Cr7bXwjr4jHBv64N6oFWhJW.png',NULL,'2026-08-03 11:48:51','2026-08-03 11:48:51'),
(11,'image','ChatGPT Image Dec 28, 2025, 09_28_35 AM.png',NULL,'shops/banner/8UdhG3ofCVfpbQBNUVDY2nMohwPXg4SFwLjmbMq3.png',NULL,'2026-08-03 11:48:51','2026-08-03 11:48:51'),
(12,'image','actual_logo.png',NULL,'users/profile/F4Yn3R3zD1Ep2f7y7Qo8N2Em3bPZ20Da127OycrW.png',NULL,'2026-08-03 15:28:56','2026-08-03 15:28:56'),
(13,'image','actual_logo.png',NULL,'shops/logo/b4OC2YTEF7biO4Jtnfjmy0ffoeJVcbDwz6xzg8rl.png',NULL,'2026-08-03 15:28:58','2026-08-03 15:28:58'),
(14,'image','addclass.png',NULL,'shops/banner/nuoBZv3AH1Lwe3suKRUokHY9ZJbXGI4Ih0F1unfU.png',NULL,'2026-08-03 15:28:58','2026-08-03 15:28:58');
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `menus` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `ar_name` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `original_name` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `original_url` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  `target` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT '_self',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_external` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menus`
--

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `menus` VALUES
(1,'Home','الرئيسية','/','Home','Home','/',1,'_self',1,1,0,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(2,'Products','المنتجات','/products','Products','Products','/products',2,'_self',1,1,0,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(3,'Digital Products','المنتجات الرقمية','/digital-products','Digital Products','Digital Products','/digital-products',3,'_self',1,1,0,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(4,'Shops','المتاجر','/shops','Shops','Shops','/shops',4,'_self',1,1,0,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(5,'Most Popular','الاكثر شعبية','/most-popular','Most Popular','Most Popular','/most-popular',5,'_self',1,1,0,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(6,'Best Deal','أفضل العروض','/best-deal','Best Deal','Best Deal','/best-deal',6,'_self',1,1,0,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(7,'Contact','اتصل بنا','/contact-us','Contact','Contact','/contact-us',7,'_self',1,1,0,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(8,'Blogs','المدونات','/blogs','Blogs','Blogs','/blogs',8,'_self',1,1,0,'2026-08-03 08:41:09','2026-08-03 08:41:09');
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=183 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `migrations` VALUES
(1,'2019_08_19_000000_create_failed_jobs_table',1),
(2,'2019_12_14_000001_create_personal_access_tokens_table',1),
(3,'2024_01_16_000214_create_permission_tables',1),
(4,'2024_01_16_000324_create_media_table',1),
(5,'2024_01_16_000454_create_users_table',1),
(6,'2024_01_16_104638_create_customers_table',1),
(7,'2024_01_16_105000_create_categories_table',1),
(8,'2024_01_16_105234_create_shops_table',1),
(9,'2024_01_16_105314_create_brands_table',1),
(10,'2024_01_16_105346_create_products_table',1),
(11,'2024_01_16_110908_create_banners_table',1),
(12,'2024_01_16_111152_create_reviews_table',1),
(13,'2024_01_16_112138_create_addresses_table',1),
(14,'2024_01_16_112545_create_coupons_table',1),
(15,'2024_01_16_115937_create_shop_categories_table',1),
(16,'2024_01_17_002344_create_colors_table',1),
(17,'2024_01_17_072702_create_product_colors_table',1),
(18,'2024_01_17_073458_create_sizes_table',1),
(19,'2024_01_17_073725_create_units_table',1),
(20,'2024_01_17_074135_create_product_units_table',1),
(21,'2024_01_17_074229_create_product_sizes_table',1),
(22,'2024_01_17_074745_create_verify_otps_table',1),
(23,'2024_01_17_075503_create_product_thumbnails_table',1),
(24,'2024_01_17_080646_create_product_categories_table',1),
(25,'2024_01_17_092300_create_favorites_table',1),
(26,'2024_01_17_112948_create_orders_table',1),
(27,'2024_01_17_114308_create_order_products_table',1),
(28,'2024_01_23_045138_create_legal_pages_table',1),
(29,'2024_01_23_045412_create_supports_table',1),
(30,'2024_01_27_072753_create_generate_settings_table',1),
(31,'2024_02_29_111443_add_is_approve_column_to_products_table',1),
(32,'2024_03_05_113904_add_unit_id_to_products_table',1),
(33,'2024_03_06_101936_add_price_column_to_product_sizes_table',1),
(34,'2024_03_10_110137_add_currency_column_to_generale_setting_table',1),
(35,'2024_03_12_040056_add_code_to_products_table',1),
(36,'2024_03_16_075329_add_order_id_to_reviews_table',1),
(37,'2024_03_17_063030_change_shop_id_to_coupons_table',1),
(38,'2024_03_17_100252_create_coupon_collects_table',1),
(39,'2024_03_18_082804_add_footer_column_to_generale_settings_table',1),
(40,'2024_03_20_031250_add_column_to_coupons_table',1),
(41,'2024_03_20_032311_create_admin_coupons_table',1),
(42,'2024_03_23_111543_create_notifications_table',1),
(43,'2024_03_24_094629_create_payment_gateways_table',1),
(44,'2024_03_25_104034_create_payments_table',1),
(45,'2024_03_25_104350_create_order_payments_table',1),
(46,'2024_03_25_114533_create_contact_uses_table',1),
(47,'2024_03_27_164439_add_column_to_payments_table',1),
(48,'2024_03_28_095034_add_column_to_generate_settings_table',1),
(49,'2024_03_30_092829_create_wallets_table',1),
(50,'2024_03_30_093648_create_transactions_table',1),
(51,'2024_03_30_094238_create_withdraws_table',1),
(52,'2024_03_30_104019_add_column_to_orders_table',1),
(53,'2024_03_31_083538_add_column_to_notifications_table',1),
(54,'2024_04_19_173548_add_shop_type_column_to_generate_settings_table',1),
(55,'2024_04_21_121936_create_carts_table',1),
(56,'2024_04_28_104356_create_drivers_table',1),
(57,'2024_04_29_104509_create_drivers_orders_table',1),
(58,'2024_04_29_113150_add_vehicle_type_column_to_users_table',1),
(59,'2024_04_29_164336_create_device_keys_table',1),
(60,'2024_04_30_114459_add_cash_collect_to_driver_order_table',1),
(61,'2024_04_30_121054_add_total_cash_collect_to_drivers_table',1),
(62,'2024_05_14_154411_create_recent_views_table',1),
(63,'2024_05_15_111324_create_flash_sales_table',1),
(64,'2024_05_15_115849_create_flash_sale_products_table',1),
(65,'2024_05_16_112807_add_column_to_supports_table',1),
(66,'2024_05_16_116825_add_column_to_flash_sale_products_table',1),
(67,'2024_05_18_111152_add_off_day_to_shops_table',1),
(68,'2024_05_18_163651_add_column_to_generate_settings_table',1),
(69,'2024_05_19_122837_add_column_to_generate_settings_table',1),
(70,'2024_05_20_163704_create_ads_table',1),
(71,'2024_05_21_155258_create_delivery_charges_table',1),
(72,'2024_05_21_191749_create_social_links_table',1),
(73,'2024_05_26_131755_create_support_tickets_table',1),
(74,'2024_05_26_131930_create_support_ticket_messages_table',1),
(75,'2024_05_26_135940_create_support_ticket_attachment_table',1),
(76,'2024_05_28_103844_create_ticket_issue_types_table',1),
(77,'2024_05_30_182019_add_column_to_generate_settings_table',1),
(78,'2024_06_05_165137_add_column_to_media_table',1),
(79,'2024_06_08_154510_create_galleries_table',1),
(80,'2024_06_09_103825_create_sub_categories_table',1),
(81,'2024_06_09_110839_create_category_subcategories_table',1),
(82,'2024_06_09_132729_create_product_subcategorys_table',1),
(83,'2024_06_22_095856_create_s_m_s_configs_table',1),
(84,'2024_06_23_154709_add_column_to_generate_settings_table',1),
(85,'2024_06_24_133734_add_column_to_carts_table',1),
(86,'2024_06_25_110336_add_column_to_generate_settings_table',1),
(87,'2024_06_25_114728_add_column_to_reviews_table',1),
(88,'2024_06_27_112507_add_column_to_categories_table',1),
(89,'2024_06_29_104005_add_column_to_categories_table',1),
(90,'2024_06_29_104453_add_column_to_sub_categories_table',1),
(91,'2024_06_29_114916_add_column_to_brands_table',1),
(92,'2024_06_29_114927_add_column_to_colors_table',1),
(93,'2024_06_29_114939_add_column_to_sizes_table',1),
(94,'2024_06_29_115100_add_column_to_products_table',1),
(95,'2024_07_01_103743_create_languages_table',1),
(96,'2024_07_01_110802_add_softdelete_to_users_table',1),
(97,'2024_07_03_092913_create_pos_carts_table',1),
(98,'2024_07_03_101851_create_pos_cart_products_table',1),
(99,'2024_07_03_103622_add_column_to_orders_table',1),
(100,'2024_07_04_170256_update_customer_id_column_to_orders_table',1),
(101,'2024_07_07_124525_add_draft_column_to_pos_carts_table',1),
(102,'2024_07_09_142655_add_column_to_pos_carts_table',1),
(103,'2024_09_15_093610_create_theme_colors_table',1),
(104,'2024_09_15_113123_add_clumns_to_users_table',1),
(105,'2024_09_17_101004_add_clumn_to_products_table',1),
(106,'2024_09_23_115749_add_column_to_users_table',1),
(107,'2024_09_24_101919_add_column_to_roles_table',1),
(108,'2024_09_24_105224_create_user_non_permissions_table',1),
(109,'2024_09_26_114754_create_verify_manages_table',1),
(110,'2024_09_30_135048_change_column_to_flash_sales_table',1),
(111,'2024_09_30_164906_add_column_to_flash_sale_products_table',1),
(112,'2024_10_02_125419_add_column_to_flash_sales_table',1),
(113,'2024_10_05_135418_add_column_to_flash_sale_products_table',1),
(114,'2024_10_08_113905_add_column_to_order_products_table',1),
(115,'2024_10_10_155932_create_google_re_captchas_table',1),
(116,'2024_10_14_160335_create_social_auths_table',1),
(117,'2024_10_14_170543_add_columns_to_users_table',1),
(118,'2024_10_19_104732_add_columns_to_product_colors_table',1),
(119,'2024_11_24_124258_create_vat_taxes_table',1),
(120,'2024_11_24_165734_create_product_vat_taxes_table',1),
(121,'2024_11_25_110112_add_column_to_orders_table',1),
(122,'2024_11_28_170135_create_blogs_table',1),
(123,'2024_11_28_171145_create_tags_table',1),
(124,'2024_11_28_171247_create_blog_tags_table',1),
(125,'2024_11_28_171333_create_blog_views_table',1),
(126,'2025_01_06_145615_add_column_to_carts_table',1),
(127,'2025_01_07_113201_add_column_to_products_table',1),
(128,'2025_01_07_115807_add_column_to_languages_table',1),
(129,'2025_01_26_100341_create_translate_utilities_table',1),
(130,'2025_01_26_103530_create_currencies_table',1),
(131,'2025_01_26_112926_change_password_column_to_users_table',1),
(132,'2025_01_26_113220_create_product_translations_table',1),
(133,'2025_01_26_155516_add_currency_id_column_to_generate_settings_table',1),
(134,'2025_01_28_174131_add_column_to_verify_manages_table',1),
(135,'2025_02_03_111244_change_column_to_shops_table',1),
(136,'2025_02_13_111656_create_menus_table',1),
(137,'2025_02_16_100246_create_pages_table',1),
(138,'2025_02_17_101904_add_column_to_verify_manages_table',1),
(139,'2025_02_17_102712_create_countries_table',1),
(140,'2025_02_18_160537_create_order_vat_taxes_table',1),
(141,'2025_02_22_111431_add_column_to_generate_settings_table',1),
(142,'2025_02_22_152711_create_footers_table',1),
(143,'2025_02_22_154855_create_footer_items_table',1),
(144,'2025_04_17_105545_create_subscription_plans_table',1),
(145,'2025_04_17_105627_create_shop_subscriptions_table',1),
(146,'2025_05_04_111353_create_shop_user_table',1),
(147,'2025_05_04_111844_create_shop_user_chats_table',1),
(148,'2025_05_06_150402_add_column_to_generate_settings_table',1),
(149,'2025_05_06_174546_add_last_online_column_to_users_table',1),
(150,'2025_05_06_183511_add_last_online_column_to_shops_table',1),
(151,'2025_07_02_165205_create_paypal_payments_table',1),
(152,'2025_07_14_153807_add_column_to_social_links_table',1),
(153,'2025_07_16_142728_add_column_to_pos_carts_table',1),
(154,'2025_08_11_180401_add_new_coloum_to_generate_settings',1),
(155,'2025_08_18_165743_add_new_coloum_to_generate_settings',1),
(156,'2025_08_27_152721_create_return_orders_table',1),
(157,'2025_08_27_153102_create_return_order_details_table',1),
(158,'2025_08_28_124115_add_new_coloum_to_generate_settings_table',1),
(159,'2025_09_25_180903_create_product_attachments_table',1),
(160,'2025_09_25_181339_add_column_to_products_table',1),
(161,'2025_09_28_124136_create_product_licenses_table',1),
(162,'2025_09_29_130047_add_column_to_product_licenses_table',1),
(163,'2025_10_01_112743_add_column_to_product_licenses_table',1),
(164,'2025_11_02_153428_create_module_settings_table',1),
(165,'2025_11_25_103004_create_cart_access_tokens_table',1),
(166,'2025_12_15_163627_add_softdelete_to_drivers_table',1),
(167,'2025_12_15_163653_add_softdelete_to_shops_table',1),
(168,'2025_12_25_103350_add_coloums_to_order_products_table',1),
(169,'2025_12_27_062612_add_index_to_products_table',1),
(170,'2025_12_29_154611_create_driver_locations_table',1),
(171,'2026_01_04_112219_create_areas_table',1),
(172,'2026_01_04_131609_add_area_to_addresses_table',1),
(173,'2026_01_04_152627_add_area_to_orders_table',1),
(174,'2026_01_26_134407_add_soft_delete_to_products_table',1),
(175,'2026_01_29_150919_add_ar_to_menus_table',1),
(176,'2026_01_29_154737_add_titlear_to_footers_table',1),
(177,'2026_01_29_154810_add_titlear_to_footer_items_table',1),
(178,'2026_07_27_000001_create_warehouses_tables',1),
(179,'2026_07_30_212249_drop_shop_id_from_warehouses_table',1),
(180,'2026_08_01_000001_add_parent_shop_id_to_shops_table',2),
(181,'2026_08_01_000002_create_shop_monthly_payouts_table',2),
(182,'2026_08_02_000000_drop_subscription_tables',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `model_has_roles` VALUES
(1,'App\\Models\\User',1),
(3,'App\\Models\\User',1),
(3,'App\\Models\\User',3),
(3,'App\\Models\\User',4),
(3,'App\\Models\\User',5);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `module_settings`
--

DROP TABLE IF EXISTS `module_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `module_settings` (
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `is_first` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `module_settings`
--

LOCK TABLES `module_settings` WRITE;
/*!40000 ALTER TABLE `module_settings` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `module_settings` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `icon` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `shop_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `withdraw_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_shop_id_foreign` (`shop_id`),
  KEY `notifications_user_id_foreign` (`user_id`),
  KEY `notifications_withdraw_id_foreign` (`withdraw_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `order_payments`
--

DROP TABLE IF EXISTS `order_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_payments` (
  `order_id` bigint(20) unsigned NOT NULL,
  `payment_id` bigint(20) unsigned NOT NULL,
  KEY `order_payments_order_id_foreign` (`order_id`),
  KEY `order_payments_payment_id_foreign` (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_payments`
--

LOCK TABLES `order_payments` WRITE;
/*!40000 ALTER TABLE `order_payments` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `order_payments` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `order_products`
--

DROP TABLE IF EXISTS `order_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '1',
  `color` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `size` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price` double DEFAULT NULL,
  `buying_price` double DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_products_product_id_foreign` (`product_id`),
  KEY `order_products_order_id_product_id_index` (`order_id`,`product_id`),
  KEY `order_products_created_at_index` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_products`
--

LOCK TABLES `order_products` WRITE;
/*!40000 ALTER TABLE `order_products` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `order_products` VALUES
(1,1,2,1,'yellow','small',NULL,100,40,'2026-08-03 11:51:37','2026-08-03 11:51:37');
/*!40000 ALTER TABLE `order_products` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `order_vat_taxes`
--

DROP TABLE IF EXISTS `order_vat_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_vat_taxes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `percentage` double NOT NULL DEFAULT '0',
  `amount` double NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_vat_taxes_order_id_foreign` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_vat_taxes`
--

LOCK TABLES `order_vat_taxes` WRITE;
/*!40000 ALTER TABLE `order_vat_taxes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `order_vat_taxes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `shop_id` bigint(20) unsigned NOT NULL,
  `pos_order` tinyint(1) NOT NULL DEFAULT '0',
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `order_code` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `prefix` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `coupon_id` bigint(20) unsigned DEFAULT NULL,
  `coupon_discount` double DEFAULT NULL,
  `pick_date` timestamp NULL DEFAULT NULL,
  `delivery_date` timestamp NULL DEFAULT NULL,
  `payable_amount` double NOT NULL,
  `total_amount` double NOT NULL,
  `tax_amount` double DEFAULT '0',
  `discount` double DEFAULT '0',
  `delivery_charge` double NOT NULL DEFAULT '0',
  `payment_status` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `order_status` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `payment_method` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_id` bigint(20) unsigned DEFAULT NULL,
  `instruction` longtext COLLATE utf8_unicode_ci,
  `invoice_path` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `delivered_at` timestamp NULL DEFAULT NULL,
  `admin_commission` double DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `order_area` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `orders_shop_id_foreign` (`shop_id`),
  KEY `orders_customer_id_foreign` (`customer_id`),
  KEY `orders_coupon_id_foreign` (`coupon_id`),
  KEY `orders_address_id_foreign` (`address_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `orders` VALUES
(1,2,1,NULL,'000002','RC',NULL,0,NULL,NULL,100,100,0,0,0,'Paid','Delivered','Cash Payment',NULL,NULL,NULL,NULL,0,'2026-08-03 11:51:37','2026-08-03 11:51:37',NULL);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_editable` tinyint(1) NOT NULL DEFAULT '1',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `pages` VALUES
(1,'Products','products','products',NULL,1,0,1,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(2,'Shops','shops','shops',NULL,1,0,1,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(3,'Most Popular','most-popular','most-popular',NULL,1,0,1,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(4,'Digital Products','digital-products','digital-products',NULL,1,0,1,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(5,'Best Deal','best-deal','best-deal',NULL,1,0,1,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(6,'Contact','contact-us','contact-us',NULL,1,0,1,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(7,'Blogs','blogs','blogs',NULL,1,0,1,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(8,'About Us','about-us','about-us','<html><head><title>Non et.</title></head><body><form action=\"example.org\" method=\"POST\"><label for=\"username\">non</label><input type=\"text\" id=\"username\"><label for=\"password\">sed</label><input type=\"password\" id=\"password\"></form><div class=\"alias\"></div><div id=\"15977\"><div id=\"33948\"></div><div id=\"11749\"></div><div class=\"magnam\"></div></div><div class=\"quia\"></div></body></html>\n',1,1,1,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(9,'Privacy Policy','privacy-policy','privacy-policy','<html><head><title>Enim numquam necessitatibus aut id modi sint molestias.</title></head><body><form action=\"example.com\" method=\"POST\"><label for=\"username\">ducimus</label><input type=\"text\" id=\"username\"><label for=\"password\">repellat</label><input type=\"password\" id=\"password\"></form><div class=\"tenetur\"><div class=\"sunt\"></div><div id=\"36028\"></div><div class=\"beatae\"><span>Amet ea dolores ratione fugiat ipsam dicta.</span>Modi corrupti totam modi placeat consequatur consequatur doloribus tenetur delectus quis.<ul><li>Velit voluptas.</li><li>Tenetur aut laborum.</li><li>Eum voluptates vel quis.</li><li>Consequatur eum soluta consequuntur voluptas.</li><li>Nam.</li><li>Delectus ut in.</li><li>Sit quia provident quia.</li><li>Quasi et aliquam.</li><li>Cum dolor.</li><li>Pariatur aliquid quo exercitationem explicabo.</li></ul><a href=\"example.com\">Id in facilis consequatur sequi ducimus.</a><a href=\"example.org\">Similique vel ab voluptatem rerum facilis.</a></div><div class=\"at\"></div><div class=\"animi\"></div><div id=\"77959\"></div></div><div id=\"6206\"><div id=\"70085\"><span>Temporibus et sequi.</span><table><thead><tr><th>Placeat aliquam rerum.</th><th>Cumque blanditiis dolorem.</th></tr></thead><tbody><tr><td>Fugiat.</td><td>Sed asperiores voluptatibus provident magni adipisci id aperiam omnis est.</td></tr><tr><td>Ducimus non unde maxime doloribus unde quis quisquam ut.</td><td>Distinctio earum facilis molestiae dolorum iure nesciunt aut aut ipsa.</td></tr><tr><td>Culpa eum necessitatibus recusandae.</td><td>Perferendis qui aperiam.</td></tr><tr><td>Aut sed et qui laudantium.</td><td>Deserunt ex iusto ducimus eligendi quis.</td></tr><tr><td>Voluptates earum ut sed nulla rerum delectus.</td><td>Qui sit laborum ut est.</td></tr><tr><td>Tempora hic.</td><td>Optio vitae tempore corrupti vitae quos omnis omnis illum.</td></tr><tr><td>Blanditiis delectus atque ratione quia ad quibusdam eum ducimus.</td><td>Quia eius impedit accusantium quam aperiam provident atque.</td></tr><tr><td>Consequatur minima.</td><td>Doloribus non.</td></tr><tr><td>Accusamus nesciunt minima sint unde qui at.</td><td>Eos iste.</td></tr></tbody></table><h3>Inventore.</h3><ul><li>Iure delectus fugit non.</li><li>Placeat ipsam itaque sint.</li></ul></div></div><div id=\"82514\"><span>Cum.</span><i>Quam voluptatem odio voluptatum aut est.</i><table><thead><tr><th>Quam dignissimos sint ipsa est.</th><th>Aut dolor aut.</th><th>Sit reprehenderit reiciendis.</th><th>Molestiae debitis.</th><th>Veritatis sequi rerum.</th><th>Reprehenderit beatae inventore.</th></tr></thead><tbody><tr><td>Sed blanditiis enim tempora.</td><td>Qui est eaque sapiente eius aspernatur voluptate qui dolorem.</td><td>Optio facilis quisquam et error nam sint.</td><td>Repellat nisi tempore.</td><td>Temporibus occaecati nobis alias labore.</td><td>Cupiditate minima laborum in omnis ipsum ea quos non.</td></tr><tr><td>Et aspernatur reprehenderit laborum odio sed voluptatibus illo dolor sequi.</td><td>Qui ut dolorem dolor odit eos soluta.</td><td>Dignissimos quam voluptatem aut dolores assumenda porro dolores qui illo enim fugiat molestiae.</td><td>Qui natus ducimus dignissimos.</td><td>Accusamus.</td><td>Quae libero est maxime corporis explicabo in iusto laudantium.</td></tr><tr><td>Voluptatibus itaque non aperiam quo laborum.</td><td>Non velit.</td><td>Pariatur.</td><td>Provident.</td><td>Expedita consequuntur reprehenderit enim et delectus fugiat dolores.</td><td>Nihil quas nam architecto et laudantium nihil.</td></tr><tr><td>Corporis nihil.</td><td>Occaecati.</td><td>Rem nisi quis vel provident rem ratione quis cum aut.</td><td>Nisi et vitae assumenda minus at at ad voluptate.</td><td>Dolor blanditiis.</td><td>Reiciendis.</td></tr><tr><td>Aspernatur corporis occaecati voluptatem architecto necessitatibus ea vitae.</td><td>Vitae aliquid natus non nam vel ut sapiente veniam quia qui quod.</td><td>Quia eos ullam reprehenderit.</td><td>Enim est culpa.</td><td>Rerum est temporibus deserunt officia unde laboriosam.</td><td>Perspiciatis et suscipit.</td></tr></tbody></table><span>Odio reprehenderit.</span><i>Velit ea quia sit.</i><ul><li>Blanditiis qui.</li><li>Deleniti quis ipsam.</li><li>Incidunt possimus quibusdam et nemo.</li><li>Ut.</li></ul><span>Et consequatur eum aut sit molestiae itaque quia.</span><span>Pariatur cumque unde est et nihil quia eaque officiis id.</span></div><div class=\"aut\"></div><div id=\"81095\"><h1>Voluptas itaque reprehenderit deleniti voluptates aspernatur cumque.</h1><h3>Minima nam laborum molestias sit voluptas expedita.</h3><table><thead><tr><th>Ipsa odio et.</th><th>Et harum vitae.</th><th>Perspiciatis et.</th><th>Et et pariatur corrupti.</th></tr></thead><tbody><tr><td>Sit ad saepe accusantium.</td><td>Ipsam sit.</td><td>Nihil nemo atque totam ut consequuntur repellendus illo sint ut.</td><td>Eos at voluptas.</td></tr><tr><td>Sed.</td><td>Ipsum quis nihil et est aliquam explicabo et voluptates non maiores.</td><td>Aut cupiditate dolor suscipit placeat delectus.</td><td>Temporibus sapiente qui facilis omnis.</td></tr></tbody></table>Architecto est vero facere a voluptas.<a href=\"example.com\">Amet velit cupiditate consequatur accusamus et.</a>Aspernatur earum.</div><div id=\"44039\"></div><div class=\"dolor\"><ul><li>Ullam aut quos.</li></ul><ul><li>Maiores quae iure molestiae.</li><li>Eius voluptatum alias.</li><li>Voluptate consequuntur.</li><li>Sit excepturi laudantium sit.</li><li>Rerum.</li><li>Nobis beatae quos.</li><li>Iusto dolor rerum numquam.</li><li>Ipsum voluptatem quis.</li></ul><a href=\"example.com\">Sed fuga fugiat.</a>Est neque est et quas est eveniet nostrum consectetur quos.Ullam a laboriosam nulla eum sit ut quas et.</div><div class=\"qui\"></div><div id=\"61264\"><div id=\"48430\"><b>Magnam.</b><h2>Et similique sequi quo porro et.</h2><a href=\"example.org\">Consequatur qui omnis voluptate voluptatum.</a><h2>Voluptas qui.</h2>Molestiae quia.Est.</div><div class=\"asperiores\"><i>Deleniti aut ab quaerat totam in adipisci est ratione.</i><p>Sit eos reprehenderit fugit fugit quos.</p><ul><li>Sit aut.</li><li>Non labore omnis.</li><li>Omnis tempore voluptas.</li><li>Est assumenda doloremque laborum.</li><li>Accusamus ea occaecati enim nam.</li></ul><ul><li>Minima laboriosam et.</li><li>Ipsum molestias.</li><li>Officiis consectetur.</li><li>Voluptas aut fugit totam voluptas eveniet.</li></ul><a href=\"example.net\">Id voluptatem provident.</a><b>Maiores occaecati fugit excepturi.</b><b>Quam libero impedit omnis sit.</b></div><div class=\"quos\"></div></div></body></html>\n',1,1,1,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(10,'Terms of Service','terms-and-conditions','terms-and-conditions','<html><head><title>Delectus debitis debitis sunt et.</title></head><body><form action=\"example.com\" method=\"POST\"><label for=\"username\">tempore</label><input type=\"text\" id=\"username\"><label for=\"password\">nihil</label><input type=\"password\" id=\"password\"></form><div class=\"rem\"></div><div class=\"ut\"></div><div class=\"sit\"><div id=\"68927\"></div><div class=\"enim\"></div><div id=\"64177\"></div></div><div id=\"25814\"></div><div id=\"89703\"></div><div id=\"84776\"></div></body></html>\n',1,1,1,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(11,'Return policy / Refund Policy','return-and-refund-policy','page/return-and-refund-policy','<html><head><title>Cupiditate itaque eius impedit in voluptatum dolores.</title></head><body><form action=\"example.org\" method=\"POST\"><label for=\"username\">eveniet</label><input type=\"text\" id=\"username\"><label for=\"password\">fugiat</label><input type=\"password\" id=\"password\"></form><div id=\"8794\"></div><div class=\"saepe\"></div><div class=\"quisquam\"></div><div id=\"34123\"><a href=\"example.org\">Est nihil accusantium distinctio numquam quod.</a><b>Aliquid et et corporis sit ut ea temporibus.</b><p>Doloremque voluptas voluptatibus sint provident.</p>Et inventore fuga quibusdam veritatis repellat.Tempora rerum.<ul><li>A quod sapiente.</li><li>Quasi est.</li><li>Omnis alias voluptates.</li><li>Non.</li><li>Nobis voluptate quia.</li><li>Et dignissimos est.</li><li>Atque sed maiores eius.</li><li>Repellendus sit dolorem.</li><li>Voluptatem aut quo delectus.</li></ul><b>Dolores alias modi omnis sunt non est.</b><table><thead><tr><th>Nesciunt adipisci corrupti ea.</th><th>Voluptate est illum cum.</th><th>Quibusdam recusandae.</th><th>Rerum.</th><th>Dolorem ea minima sint.</th><th>Et quo provident deserunt.</th></tr></thead><tbody><tr><td>Recusandae pariatur itaque neque qui labore maxime.</td><td>Veritatis voluptatibus sapiente ducimus.</td><td>Optio aut illum accusantium.</td><td>Fugiat rerum.</td><td>Vel omnis ut.</td><td>Error eveniet in est molestiae temporibus.</td></tr></tbody></table><a href=\"example.org\">Aut et dolores ipsam praesentium nam iure quae nemo enim.</a></div><div class=\"aliquid\"></div><div id=\"56083\"></div><div class=\"autem\"></div><div class=\"quia\"></div><div id=\"97933\"></div><div id=\"38853\"></div></body></html>\n',1,1,0,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(12,'Shipping & Delivery Policy','shipping-and-delivery-policy','page/shipping-and-delivery-policy','<html><head><title>At pariatur vel.</title></head><body><form action=\"example.org\" method=\"POST\"><label for=\"username\">non</label><input type=\"text\" id=\"username\"><label for=\"password\">non</label><input type=\"password\" id=\"password\"></form><div class=\"tempora\"></div><div id=\"16750\"><i>Impedit quam ut.</i>Impedit voluptas distinctio eius vel earum quisquam.</div><div id=\"88201\"><div id=\"85430\"></div><div id=\"57117\"></div><div class=\"rerum\"><h1>Ut sed temporibus nihil neque dolores explicabo.</h1><h3>Placeat mollitia aut vel est.</h3><h3>Atque atque assumenda.</h3><ul><li>Et illo vitae sit.</li><li>Quia maiores enim.</li><li>Ducimus esse aspernatur.</li><li>Saepe.</li><li>Eos sapiente.</li><li>Ullam sint qui.</li></ul><a href=\"example.com\">Illo sed omnis qui architecto laudantium reprehenderit praesentium dolores accusamus.</a><ul><li>Commodi sit adipisci maxime.</li><li>Aspernatur quis.</li><li>Voluptatem temporibus.</li><li>Debitis corrupti et error molestias.</li><li>Similique et voluptas voluptas molestiae.</li><li>Eligendi expedita.</li><li>Ad et.</li></ul><b>Quasi doloremque dolores quis.</b><a href=\"example.com\">Quo voluptatum facere ratione ut et eum est id corrupti quos laboriosam hic qui.</a><a href=\"example.org\">Ducimus autem perspiciatis quae et sed.</a></div><div id=\"44464\"></div><div class=\"numquam\"><ul><li>Vel.</li></ul><p>Maxime officiis eius ad excepturi.</p><ul><li>Neque consequatur.</li><li>Architecto rem quaerat.</li><li>Saepe laboriosam est.</li><li>Molestias.</li><li>Dolor nobis.</li><li>Deleniti ipsam sunt.</li><li>Quo qui facere porro.</li><li>Qui rerum.</li><li>Aut maiores at.</li></ul><i>Qui voluptatibus velit est consequuntur minima.</i><i>Facere aliquam vitae laborum minus occaecati sit deleniti expedita at ut laudantium natus ut.</i><ul><li>Eum sit quia quo.</li><li>Amet molestias recusandae.</li><li>Eius quasi.</li><li>Provident.</li><li>Molestiae incidunt minus nobis facere.</li><li>Et eos voluptas ut.</li><li>Debitis corporis eos quaerat sint.</li><li>Dignissimos dignissimos architecto.</li><li>Ullam sint rerum ipsa.</li></ul><span>Voluptas officiis.</span><b>Repudiandae iure magnam.</b>Animi ipsa voluptates provident dolorem.Architecto molestias maiores blanditiis aliquam.</div><div id=\"54109\"></div><div id=\"18732\"><ul><li>Omnis quisquam repellat.</li><li>Debitis quam inventore itaque et.</li><li>Dolor amet aliquam.</li><li>Corporis.</li><li>Est quisquam culpa.</li><li>Earum quos eos.</li><li>Quia ut.</li></ul><i>Est qui atque et ut fugit.</i>Commodi cum illum impedit et nostrum itaque qui non.<i>Voluptate eum mollitia.</i></div><div id=\"58777\"></div><div class=\"expedita\"></div><div id=\"34753\"></div></div><div id=\"29859\"></div><div class=\"quos\"><table><thead><tr><th>Eos fugiat quia.</th><th>Ut sint ea molestiae.</th><th>Sapiente corrupti.</th></tr></thead><tbody><tr><td>Ducimus voluptas et delectus illum.</td><td>Quidem doloribus aspernatur debitis ipsa.</td><td>Illo eum quo aut quia nobis qui.</td></tr><tr><td>Aut sit quo amet.</td><td>Sunt soluta nisi inventore sequi libero expedita quod ab sit autem.</td><td>Aut nulla minus.</td></tr></tbody></table><b>Architecto et cum.</b><h2>Enim hic neque consequatur expedita eaque in id.</h2><span>Ex itaque nihil est vel.</span></div><div id=\"53958\"></div><div class=\"velit\"></div><div class=\"pariatur\"></div></body></html>\n',1,1,0,'2026-08-03 08:41:09','2026-08-03 08:41:09');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `payment_gateways`
--

DROP TABLE IF EXISTS `payment_gateways`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_gateways` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `media_id` bigint(20) unsigned DEFAULT NULL,
  `config` json DEFAULT NULL,
  `mode` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'test' COMMENT 'test or live',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `alias` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'controller nameSpace',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_gateways_media_id_foreign` (`media_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_gateways`
--

LOCK TABLES `payment_gateways` WRITE;
/*!40000 ALTER TABLE `payment_gateways` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `payment_gateways` VALUES
(1,'Stripe','stripe',NULL,'{\"secret_key\": \"\", \"published_key\": \"\"}','test',1,'Stripe','2026-08-03 08:41:09','2026-08-03 08:41:09'),
(2,'PayPal','paypal',NULL,'{\"client_id\": \"\", \"client_secret\": \"\"}','test',1,'PayPal','2026-08-03 08:41:09','2026-08-03 08:41:09'),
(3,'Razorpay','razorpay',NULL,'{\"key\": \"\", \"secret\": \"\"}','test',1,'Razorpay','2026-08-03 08:41:09','2026-08-03 08:41:09'),
(4,'Paystack','paystack',NULL,'{\"public_key\": \"\", \"secret_key\": \"\", \"machant_email\": \"\"}','test',1,'PayStack','2026-08-03 08:41:09','2026-08-03 08:41:09'),
(5,'aamarPay','aamarpay',NULL,'{\"store_id\": \"\", \"signature_key\": \"\"}','test',1,'AamarPay','2026-08-03 08:41:09','2026-08-03 08:41:09'),
(6,'BKash','bKash',NULL,'{\"app_key\": \"\", \"password\": \"\", \"username\": \"\", \"app_secret_key\": \"\"}','test',1,'Bkash','2026-08-03 08:41:09','2026-08-03 08:41:09'),
(7,'PayTabs','paytabs',NULL,'{\"base_url\": \"https://secure-global.paytabs.com\", \"currency\": \"USD\", \"profile_id\": \"\", \"server_key\": \"\"}','test',1,'PayTabs','2026-08-03 08:41:09','2026-08-03 08:41:09'),
(8,'QiCard','qicard',NULL,'{\"currency\": \"IQD\", \"password\": \"\", \"username\": \"\", \"terminalId\": \"\"}','test',1,'QiCard','2026-08-03 08:41:09','2026-08-03 08:41:09'),
(9,'PayU','payu',NULL,'{\"base_url\": \"https://secure.payu.in/_payment\", \"merchant_key\": \"\", \"merchant_salt\": \"\"}','test',1,'PayU','2026-08-03 08:41:09','2026-08-03 08:41:09'),
(10,'CashFree','cashfree',NULL,'{\"app_id\": \"\", \"base_url\": \"https://api.cashfree.com/pg/orders\", \"secret_key\": \"\"}','test',1,'CashFree','2026-08-03 08:41:09','2026-08-03 08:41:09'),
(11,'JazzCash','jazzcash',NULL,'{\"note\": \"You have to setup this return URL in your JazzCash merchant account dashboard: http://localhost:8888/janmitram-app/payment/success\", \"base_url\": \"https://sandbox.jazzcash.com.pk/CustomerPortal/transactionmanagement/merchantform\", \"password\": \"\", \"merchant_id\": \"\", \"integrity_salt\": \"\"}','test',1,'JazzCash','2026-08-03 08:41:09','2026-08-03 08:41:09');
/*!40000 ALTER TABLE `payment_gateways` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `amount` double NOT NULL DEFAULT '0',
  `currency` varchar(191) COLLATE utf8_unicode_ci DEFAULT 'USD',
  `payment_method` varchar(191) COLLATE utf8_unicode_ci DEFAULT 'cash',
  `is_paid` tinyint(1) NOT NULL DEFAULT '0',
  `payment_token` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `paypal_payments`
--

DROP TABLE IF EXISTS `paypal_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `paypal_payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `payment_id` bigint(20) unsigned NOT NULL,
  `order_id` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paypal_payments_payment_id_foreign` (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paypal_payments`
--

LOCK TABLES `paypal_payments` WRITE;
/*!40000 ALTER TABLE `paypal_payments` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `paypal_payments` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=331 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `permissions` VALUES
(1,'admin.dashboard.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(2,'admin.dashboard.notification','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(3,'admin.shop.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(4,'admin.shop.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(5,'admin.shop.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(6,'admin.shop.status.toggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(7,'admin.shop.show','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(8,'admin.shop.orders','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(9,'admin.shop.products','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(10,'admin.shop.reset.password','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(11,'admin.product.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(12,'admin.product.approve','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(13,'admin.product.show','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(14,'admin.product.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(15,'admin.coupon.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(16,'admin.coupon.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(17,'admin.coupon.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(18,'admin.coupon.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(19,'admin.withdraw.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(20,'admin.withdraw.update','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(21,'admin.withdraw.show','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(22,'admin.banner.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(23,'admin.banner.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(24,'admin.banner.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(25,'admin.banner.toggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(26,'admin.banner.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(27,'admin.ad.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(28,'admin.ad.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(29,'admin.ad.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(30,'admin.ad.toggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(31,'admin.ad.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(32,'admin.order.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(33,'admin.order.show','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(34,'admin.order.status.change','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(35,'admin.order.payment.status.toggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(36,'admin.order.assign.rider','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(37,'admin.review.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(38,'admin.review.toggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(39,'admin.brand.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(40,'admin.brand.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(41,'admin.brand.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(42,'admin.brand.toggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(43,'admin.brand.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(44,'admin.color.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(45,'admin.color.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(46,'admin.color.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(47,'admin.color.toggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(48,'admin.color.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(49,'admin.size.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(50,'admin.size.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(51,'admin.size.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(52,'admin.size.toggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(53,'admin.size.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(54,'admin.unit.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(55,'admin.unit.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(56,'admin.unit.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(57,'admin.unit.toggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(58,'admin.unit.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(59,'admin.category.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(60,'admin.category.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(61,'admin.category.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(62,'admin.category.toggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(63,'admin.category.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(64,'admin.subcategory.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(65,'admin.subcategory.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(66,'admin.subcategory.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(67,'admin.subcategory.toggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(68,'admin.subcategory.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(69,'admin.flashSale.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(70,'admin.flashSale.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(71,'admin.flashSale.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(72,'admin.flashSale.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(73,'admin.flashSale.toggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(74,'admin.generale-setting.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(75,'admin.generale-setting.update','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(76,'admin.business-setting.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(77,'admin.business-setting.update','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(78,'admin.verification.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(79,'admin.verification.update','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(80,'admin.socialLink.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(81,'admin.socialLink.update','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(82,'admin.socialLink.toggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(83,'admin.socialAuth.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(84,'admin.socialAuth.update','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(85,'admin.socialAuth.toggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(86,'admin.menu.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(87,'admin.menu.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(88,'admin.menu.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(89,'admin.menu.remove','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(90,'admin.menu.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(91,'admin.page.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(92,'admin.page.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(93,'admin.page.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(94,'admin.page.show','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(95,'admin.page.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(96,'admin.page.generate.AI.data','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(97,'admin.country.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(98,'admin.country.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(99,'admin.country.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(100,'admin.country.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(101,'admin.area.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(102,'admin.area.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(103,'admin.area.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(104,'admin.area.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(105,'admin.area.toggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(106,'admin.currency.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(107,'admin.currency.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(108,'admin.currency.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(109,'admin.currency.toggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(110,'admin.currency.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(111,'admin.themeColor.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(112,'admin.themeColor.update','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(113,'admin.themeColor.change','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(114,'admin.deliveryCharge.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(115,'admin.deliveryCharge.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(116,'admin.deliveryCharge.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(117,'admin.deliveryCharge.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(118,'admin.pusher.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(119,'admin.pusher.update','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(120,'admin.mailConfig.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(121,'admin.mailConfig.update','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(122,'admin.paymentGateway.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(123,'admin.paymentGateway.update','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(124,'admin.paymentGateway.toggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(125,'admin.sms-gateway.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(126,'admin.sms-gateway.update','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(127,'admin.googleReCaptcha.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(128,'admin.googleReCaptcha.update','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(129,'admin.contactUs.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(130,'admin.contactUs.update','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(131,'admin.firebase.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(132,'admin.firebase.update','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(133,'admin.profile.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(134,'admin.profile.update','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(135,'admin.profile.change-password','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(136,'admin.rider.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(137,'admin.rider.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(138,'admin.rider.show','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(139,'admin.rider.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(140,'admin.rider.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(141,'admin.rider.toggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(142,'admin.rider.assign.order','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(143,'admin.customer.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(144,'admin.customer.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(145,'admin.customer.show','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(146,'admin.customer.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(147,'admin.customer.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(148,'admin.customer.toggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(149,'admin.customer.reset.password','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(150,'admin.customerNotification.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(151,'admin.customerNotification.send','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(152,'admin.language.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(153,'admin.language.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(154,'admin.language.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(155,'admin.language.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(156,'admin.language.export','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(157,'admin.language.import','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(158,'admin.employee.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(159,'admin.employee.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(160,'admin.employee.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(161,'admin.employee.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(162,'admin.employee.toggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(163,'admin.employee.reset.password','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(164,'admin.employee.permission','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(165,'admin.employee.permission.update','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(166,'admin.role.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(167,'admin.role.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(168,'admin.role.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(169,'admin.role.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(170,'admin.role.permission','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(171,'admin.role.permission.update','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(172,'admin.ticketIssueType.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(173,'admin.ticketIssueType.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(174,'admin.ticketIssueType.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(175,'admin.ticketIssueType.toggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(176,'admin.ticketIssueType.delete','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(177,'admin.supportTicket.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(178,'admin.supportTicket.show','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(179,'admin.supportTicket.setScheduled','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(180,'admin.supportTicket.sendMessage','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(181,'admin.supportTicket.updateStatus','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(182,'admin.supportTicket.pinMessage','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(183,'admin.supportTicket.chatToggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(184,'admin.support.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(185,'admin.support.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(186,'admin.vatTax.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(187,'admin.vatTax.order.update','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(188,'admin.vatTax.store','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(189,'admin.vatTax.update','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(190,'admin.vatTax.toggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(191,'admin.vatTax.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(192,'admin.blog.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(193,'admin.blog.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(194,'admin.blog.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(195,'admin.blog.toggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(196,'admin.blog.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(197,'admin.blog.generate.AI.data','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(198,'admin.aiPrompt.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(199,'admin.aiPrompt.configure','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(200,'admin.aiPrompt.configure.update','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(201,'admin.aiPrompt.update','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(202,'admin.returnOrder.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(203,'admin.returnOrder.show','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(204,'admin.returnOrder.payment.status','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(205,'admin.returnOrder.reject','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(206,'admin.conversation.customer.chat.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(207,'admin.conversation.getUsers','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(208,'admin.conversation.getMessageAdmin','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(209,'admin.conversation.sendMessageAdmin','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(210,'admin.warehouse.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(211,'admin.warehouse.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(212,'admin.warehouse.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(213,'admin.warehouse.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(214,'admin.warehouse.show','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(215,'admin.warehouse.stock','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(216,'admin.warehouse.stock.add','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(217,'admin.stock-request.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(218,'admin.stock-request.show','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(219,'admin.stock-request.approve','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(220,'admin.stock-request.reject','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(221,'admin.warehouse-transfer.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(222,'admin.warehouse-transfer.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(223,'admin.warehouse-transfer.store','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(224,'admin.warehouse-transfer.show','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(225,'admin.warehouse-transfer.complete','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(226,'admin.warehouse-transfer.cancel','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(227,'admin.payout.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(228,'admin.payout.run','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(229,'admin.payout.network','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(230,'admin.payout.guide','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(231,'admin.payout.slip','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(232,'admin.project-guide.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(233,'shop.dashboard.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(234,'shop.dashboard.notification','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(235,'shop.order.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(236,'shop.order.show','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(237,'shop.order.status.change','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(238,'shop.product.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(239,'shop.product.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(240,'shop.product.show','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(241,'shop.product.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(242,'shop.product.toggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(243,'shop.product.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(244,'shop.product.barcode','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(245,'shop.product.generate.AI.data','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(246,'shop.flashSale.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(247,'shop.flashSale.show','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(248,'shop.flashSale.productStore','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(249,'shop.flashSale.productRemove','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(250,'shop.flashSale.product.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(251,'shop.voucher.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(252,'shop.voucher.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(253,'shop.voucher.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(254,'shop.voucher.toggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(255,'shop.voucher.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(256,'shop.bulk-product-import.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(257,'shop.bulk-product-import.store','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(258,'shop.bulk-product-export.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(259,'shop.bulk-product-export.demo','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(260,'shop.bulk-product-export.export','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(261,'shop.gallery.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(262,'shop.gallery.store','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(263,'shop.pos.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(264,'shop.pos.sales','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(265,'shop.pos.draft','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(266,'shop.employee.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(267,'shop.employee.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(268,'shop.employee.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(269,'shop.employee.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(270,'shop.employee.toggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(271,'shop.employee.reset.password','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(272,'shop.employee.permission','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(273,'shop.employee.permission.update','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(274,'shop.profile.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(275,'shop.profile.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(276,'shop.profile.change-password','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(277,'shop.returnOrder.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(278,'shop.returnOrder.show','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(279,'shop.returnOrder.status.change','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(280,'shop.supplier.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(281,'shop.supplier.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(282,'shop.supplier.store','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(283,'shop.supplier.show','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(284,'shop.supplier.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(285,'shop.supplier.update','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(286,'shop.supplier.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(287,'shop.supplier.toggle','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(288,'shop.supplier.statistic','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(289,'shop.supplier.payment','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(290,'shop.purchase.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(291,'shop.purchase.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(292,'shop.purchase.store','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(293,'shop.purchase.show','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(294,'shop.purchase.edit','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(295,'shop.purchase.update','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(296,'shop.purchase.destroy','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(297,'shop.purchase.attach.product','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(298,'shop.purchase.products','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(299,'shop.purchase.makeReceived','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(300,'shop.purchase.product.delete.barcode','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(301,'shop.purchase.invoice.search','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(302,'shop.purchase.invoice.add','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(303,'shop.purchase.summary','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(304,'shop.purchase.purchaseInvoice','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(305,'shop.purchase.allProduct.stockSummary','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(306,'shop.purchaseReturn.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(307,'shop.purchaseReturn.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(308,'shop.purchaseReturn.store','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(309,'shop.purchaseReturn.show','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(310,'shop.purchaseReturn.invoice.search','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(311,'shop.purchaseReturn.Invoice','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(312,'shop.purchaseReturn.invoice.add','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(313,'shop.stock-request.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(314,'shop.stock-request.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(315,'shop.stock-request.store','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(316,'shop.stock-request.show','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(317,'shop.payout.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(318,'shop.payout.network','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(319,'shop.payout.network.create','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(320,'shop.payout.network.store','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(321,'shop.payout.slip','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(322,'shop.brand.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(323,'shop.color.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(324,'shop.size.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(325,'shop.unit.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(326,'shop.category.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(327,'shop.subcategory.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(328,'shop.withdraw.index','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(329,'shop.withdraw.store','web','2026-08-03 08:41:08','2026-08-03 08:41:08'),
(330,'shop.withdraw.show','web','2026-08-03 08:41:08','2026-08-03 08:41:08');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `pos_cart_products`
--

DROP TABLE IF EXISTS `pos_cart_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_cart_products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pos_cart_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '1',
  `brand` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `color` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `size` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pos_cart_products_pos_cart_id_foreign` (`pos_cart_id`),
  KEY `pos_cart_products_product_id_foreign` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_cart_products`
--

LOCK TABLES `pos_cart_products` WRITE;
/*!40000 ALTER TABLE `pos_cart_products` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `pos_cart_products` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `pos_carts`
--

DROP TABLE IF EXISTS `pos_carts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_carts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `shop_id` bigint(20) unsigned NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `is_draft` tinyint(1) NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `coupon_id` bigint(20) unsigned DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `subtotal` double DEFAULT NULL,
  `total` double DEFAULT NULL,
  `note` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pos_carts_shop_id_foreign` (`shop_id`),
  KEY `pos_carts_user_id_foreign` (`user_id`),
  KEY `pos_carts_coupon_id_foreign` (`coupon_id`),
  KEY `pos_carts_created_by_foreign` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_carts`
--

LOCK TABLES `pos_carts` WRITE;
/*!40000 ALTER TABLE `pos_carts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `pos_carts` VALUES
(2,'4Q832sODOBwk','::1',2,3,0,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-03 11:51:37','2026-08-03 11:51:37');
/*!40000 ALTER TABLE `pos_carts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `product_attachments`
--

DROP TABLE IF EXISTS `product_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_attachments` (
  `product_id` bigint(20) unsigned NOT NULL,
  `media_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `product_attachments_product_id_foreign` (`product_id`),
  KEY `product_attachments_media_id_foreign` (`media_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_attachments`
--

LOCK TABLES `product_attachments` WRITE;
/*!40000 ALTER TABLE `product_attachments` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `product_attachments` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `product_categories`
--

DROP TABLE IF EXISTS `product_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_categories` (
  `product_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  KEY `product_categories_product_id_foreign` (`product_id`),
  KEY `product_categories_category_id_foreign` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_categories`
--

LOCK TABLES `product_categories` WRITE;
/*!40000 ALTER TABLE `product_categories` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `product_categories` VALUES
(1,1),
(2,1);
/*!40000 ALTER TABLE `product_categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `product_colors`
--

DROP TABLE IF EXISTS `product_colors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_colors` (
  `product_id` bigint(20) unsigned NOT NULL,
  `color_id` bigint(20) unsigned NOT NULL,
  `price` double DEFAULT '0',
  KEY `product_colors_product_id_foreign` (`product_id`),
  KEY `product_colors_color_id_foreign` (`color_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_colors`
--

LOCK TABLES `product_colors` WRITE;
/*!40000 ALTER TABLE `product_colors` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `product_colors` VALUES
(1,1,0),
(2,1,0);
/*!40000 ALTER TABLE `product_colors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `product_licenses`
--

DROP TABLE IF EXISTS `product_licenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_licenses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `order_id` bigint(20) unsigned DEFAULT NULL,
  `product_license` text COLLATE utf8_unicode_ci,
  `is_used` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_licenses_product_id_foreign` (`product_id`),
  KEY `product_licenses_user_id_foreign` (`user_id`),
  KEY `product_licenses_order_id_foreign` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_licenses`
--

LOCK TABLES `product_licenses` WRITE;
/*!40000 ALTER TABLE `product_licenses` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `product_licenses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `product_sizes`
--

DROP TABLE IF EXISTS `product_sizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_sizes` (
  `product_id` bigint(20) unsigned NOT NULL,
  `size_id` bigint(20) unsigned NOT NULL,
  `price` double DEFAULT NULL,
  KEY `product_sizes_product_id_foreign` (`product_id`),
  KEY `product_sizes_size_id_foreign` (`size_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_sizes`
--

LOCK TABLES `product_sizes` WRITE;
/*!40000 ALTER TABLE `product_sizes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `product_sizes` VALUES
(1,1,0),
(2,1,0);
/*!40000 ALTER TABLE `product_sizes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `product_subcategories`
--

DROP TABLE IF EXISTS `product_subcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_subcategories` (
  `sub_category_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  KEY `product_subcategories_sub_category_id_foreign` (`sub_category_id`),
  KEY `product_subcategories_product_id_foreign` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_subcategories`
--

LOCK TABLES `product_subcategories` WRITE;
/*!40000 ALTER TABLE `product_subcategories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `product_subcategories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `product_thumbnails`
--

DROP TABLE IF EXISTS `product_thumbnails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_thumbnails` (
  `product_id` bigint(20) unsigned NOT NULL,
  `media_id` bigint(20) unsigned NOT NULL,
  KEY `product_thumbnails_product_id_foreign` (`product_id`),
  KEY `product_thumbnails_media_id_foreign` (`media_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_thumbnails`
--

LOCK TABLES `product_thumbnails` WRITE;
/*!40000 ALTER TABLE `product_thumbnails` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `product_thumbnails` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `product_translations`
--

DROP TABLE IF EXISTS `product_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_translations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `short_description` text COLLATE utf8_unicode_ci,
  `description` longtext COLLATE utf8_unicode_ci,
  `lang` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_translations_product_id_foreign` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_translations`
--

LOCK TABLES `product_translations` WRITE;
/*!40000 ALTER TABLE `product_translations` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `product_translations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `product_units`
--

DROP TABLE IF EXISTS `product_units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_units` (
  `product_id` bigint(20) unsigned NOT NULL,
  `unit_id` bigint(20) unsigned NOT NULL,
  KEY `product_units_product_id_foreign` (`product_id`),
  KEY `product_units_unit_id_foreign` (`unit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_units`
--

LOCK TABLES `product_units` WRITE;
/*!40000 ALTER TABLE `product_units` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `product_units` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `product_vat_taxes`
--

DROP TABLE IF EXISTS `product_vat_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_vat_taxes` (
  `product_id` bigint(20) unsigned NOT NULL,
  `vat_tax_id` bigint(20) unsigned NOT NULL,
  KEY `product_vat_taxes_product_id_foreign` (`product_id`),
  KEY `product_vat_taxes_vat_tax_id_foreign` (`vat_tax_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_vat_taxes`
--

LOCK TABLES `product_vat_taxes` WRITE;
/*!40000 ALTER TABLE `product_vat_taxes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `product_vat_taxes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `name_ar` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `shop_id` bigint(20) unsigned DEFAULT NULL,
  `media_id` bigint(20) unsigned DEFAULT NULL,
  `brand_id` bigint(20) unsigned DEFAULT NULL,
  `price` double NOT NULL,
  `buy_price` double DEFAULT '0',
  `quantity` int(11) NOT NULL DEFAULT '0',
  `min_order_quantity` int(11) NOT NULL DEFAULT '1',
  `discount_price` double DEFAULT NULL,
  `short_description` text COLLATE utf8_unicode_ci,
  `short_description_ar` text COLLATE utf8_unicode_ci,
  `description` longtext COLLATE utf8_unicode_ci,
  `description_ar` longtext COLLATE utf8_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `is_digital` tinyint(1) NOT NULL DEFAULT '0',
  `is_stock_managed` tinyint(1) NOT NULL DEFAULT '0',
  `master_product_id` bigint(20) unsigned DEFAULT NULL,
  `is_new` tinyint(1) NOT NULL DEFAULT '1',
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `is_approve` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `unit_id` bigint(20) unsigned DEFAULT NULL,
  `meta_title` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_description` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_keywords` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `video_id` bigint(20) unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `products_shop_id_foreign` (`shop_id`),
  KEY `products_media_id_foreign` (`media_id`),
  KEY `products_brand_id_foreign` (`brand_id`),
  KEY `products_unit_id_foreign` (`unit_id`),
  KEY `products_video_id_foreign` (`video_id`),
  KEY `products_name_index` (`name`),
  KEY `products_master_product_id_foreign` (`master_product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `products` VALUES
(1,'Haldi',NULL,NULL,'750608',1,5,1,100,40,450,1,0,'haldi',NULL,'<p>haldi</p>',NULL,1,0,1,NULL,1,0,1,'2026-08-03 11:23:39','2026-08-03 11:50:48',3,NULL,NULL,NULL,NULL,NULL),
(2,'Haldi',NULL,NULL,'750608',2,5,1,100,40,49,1,0,'haldi',NULL,'<p>haldi</p>',NULL,1,0,1,1,1,0,1,'2026-08-03 11:50:48','2026-08-03 11:51:37',3,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `recent_views`
--

DROP TABLE IF EXISTS `recent_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recent_views` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recent_views_product_id_foreign` (`product_id`),
  KEY `recent_views_user_id_foreign` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recent_views`
--

LOCK TABLES `recent_views` WRITE;
/*!40000 ALTER TABLE `recent_views` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `recent_views` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `return_order_details`
--

DROP TABLE IF EXISTS `return_order_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `return_order_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `return_order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `price` double DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `color` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `size` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `return_order_details_return_order_id_foreign` (`return_order_id`),
  KEY `return_order_details_product_id_foreign` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `return_order_details`
--

LOCK TABLES `return_order_details` WRITE;
/*!40000 ALTER TABLE `return_order_details` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `return_order_details` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `return_orders`
--

DROP TABLE IF EXISTS `return_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `return_orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned NOT NULL,
  `shop_id` bigint(20) unsigned NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  `amount` double DEFAULT NULL,
  `bank_name` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bank_account_number` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'pending',
  `payment_status` tinyint(1) NOT NULL DEFAULT '0',
  `reason` longtext COLLATE utf8_unicode_ci NOT NULL,
  `reject_note` longtext COLLATE utf8_unicode_ci,
  `return_address` longtext COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `return_orders_order_id_foreign` (`order_id`),
  KEY `return_orders_shop_id_foreign` (`shop_id`),
  KEY `return_orders_customer_id_foreign` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `return_orders`
--

LOCK TABLES `return_orders` WRITE;
/*!40000 ALTER TABLE `return_orders` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `return_orders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviews` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned DEFAULT NULL,
  `shop_id` bigint(20) unsigned DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `order_id` bigint(20) unsigned DEFAULT NULL,
  `rating` double NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reviews_customer_id_foreign` (`customer_id`),
  KEY `reviews_product_id_foreign` (`product_id`),
  KEY `reviews_shop_id_foreign` (`shop_id`),
  KEY `reviews_order_id_foreign` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `is_shop` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `roles` VALUES
(1,'root','web',0,'2026-08-03 08:41:07','2026-08-03 08:41:07'),
(2,'admin','web',0,'2026-08-03 08:41:08','2026-08-03 08:41:08'),
(3,'shop','web',0,'2026-08-03 08:41:08','2026-08-03 08:41:08'),
(4,'customer','web',0,'2026-08-03 08:41:08','2026-08-03 08:41:08'),
(5,'visitor','web',0,'2026-08-03 08:41:08','2026-08-03 08:41:08'),
(6,'driver','web',0,'2026-08-03 08:41:08','2026-08-03 08:41:08'),
(7,'supplier','web',0,'2026-08-03 08:41:08','2026-08-03 08:41:08');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `s_m_s_configs`
--

DROP TABLE IF EXISTS `s_m_s_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `s_m_s_configs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `data` json NOT NULL,
  `provider` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `s_m_s_configs`
--

LOCK TABLES `s_m_s_configs` WRITE;
/*!40000 ALTER TABLE `s_m_s_configs` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `s_m_s_configs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `shop_categories`
--

DROP TABLE IF EXISTS `shop_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_categories` (
  `shop_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  KEY `shop_categories_shop_id_foreign` (`shop_id`),
  KEY `shop_categories_category_id_foreign` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_categories`
--

LOCK TABLES `shop_categories` WRITE;
/*!40000 ALTER TABLE `shop_categories` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `shop_categories` VALUES
(1,1);
/*!40000 ALTER TABLE `shop_categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `shop_monthly_payouts`
--

DROP TABLE IF EXISTS `shop_monthly_payouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_monthly_payouts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `shop_id` bigint(20) unsigned NOT NULL,
  `year` smallint(5) unsigned NOT NULL,
  `month` tinyint(3) unsigned NOT NULL,
  `personal_sales` decimal(15,2) NOT NULL,
  `group_sales` decimal(15,2) NOT NULL,
  `group_size` int(10) unsigned NOT NULL,
  `level` tinyint(3) unsigned DEFAULT NULL,
  `phase1_amount` decimal(15,2) NOT NULL,
  `phase2_amount` decimal(15,2) NOT NULL,
  `total_payout` decimal(15,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `shop_monthly_payouts_shop_id_year_month_unique` (`shop_id`,`year`,`month`),
  CONSTRAINT `shop_monthly_payouts_shop_id_foreign` FOREIGN KEY (`shop_id`) REFERENCES `shops` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_monthly_payouts`
--

LOCK TABLES `shop_monthly_payouts` WRITE;
/*!40000 ALTER TABLE `shop_monthly_payouts` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `shop_monthly_payouts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `shop_user`
--

DROP TABLE IF EXISTS `shop_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `shop_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_user_shop_id_foreign` (`shop_id`),
  KEY `shop_user_user_id_foreign` (`user_id`),
  KEY `shop_user_product_id_foreign` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_user`
--

LOCK TABLES `shop_user` WRITE;
/*!40000 ALTER TABLE `shop_user` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `shop_user` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `shop_user_chats`
--

DROP TABLE IF EXISTS `shop_user_chats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_user_chats` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `shop_user_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned DEFAULT NULL,
  `shop_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `type` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `message` text COLLATE utf8_unicode_ci,
  `is_seen` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_user_chats_shop_user_id_foreign` (`shop_user_id`),
  KEY `shop_user_chats_product_id_foreign` (`product_id`),
  KEY `shop_user_chats_shop_id_foreign` (`shop_id`),
  KEY `shop_user_chats_user_id_foreign` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_user_chats`
--

LOCK TABLES `shop_user_chats` WRITE;
/*!40000 ALTER TABLE `shop_user_chats` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `shop_user_chats` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `shops`
--

DROP TABLE IF EXISTS `shops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shops` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `parent_shop_id` bigint(20) unsigned DEFAULT NULL,
  `warehouse_id` bigint(20) unsigned DEFAULT NULL,
  `logo_id` bigint(20) unsigned DEFAULT NULL,
  `banner_id` bigint(20) unsigned DEFAULT NULL,
  `delivery_charge` double DEFAULT '0',
  `min_order_amount` double NOT NULL DEFAULT '0',
  `prefix` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'RC',
  `address` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitude` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitude` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `opening_time` time DEFAULT NULL,
  `closing_time` time DEFAULT NULL,
  `off_day` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estimated_delivery_time` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `last_online` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shops_user_id_foreign` (`user_id`),
  KEY `shops_logo_id_foreign` (`logo_id`),
  KEY `shops_banner_id_foreign` (`banner_id`),
  KEY `shops_warehouse_id_foreign` (`warehouse_id`),
  KEY `shops_parent_shop_id_foreign` (`parent_shop_id`),
  CONSTRAINT `shops_parent_shop_id_foreign` FOREIGN KEY (`parent_shop_id`) REFERENCES `shops` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shops`
--

LOCK TABLES `shops` WRITE;
/*!40000 ALTER TABLE `shops` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `shops` VALUES
(1,'My Shop',1,NULL,1,1,2,0,1,'RC','8874 Ali Route Apt. 387\nWest Angela, AZ 67454','38.033226','162.923784','05:00:10','22:44:21',NULL,'3-4 days',1,'My Shop Description','2026-08-03 08:41:11','2026-08-03 08:41:11',NULL,NULL),
(2,'Sanganer Shop',3,1,2,7,8,0,0,'RC','417 Sanganer thana , Jaipur','27.005694931660006','75.77754972401056',NULL,NULL,NULL,NULL,1,NULL,'2026-08-03 11:44:54','2026-08-03 11:44:54',NULL,NULL),
(3,'Sanganer Shop',4,2,2,10,11,0,0,'RC','417 Sanganer thana , Jaipur','27.005694931660006','75.77754972401056',NULL,NULL,NULL,NULL,1,'ok','2026-08-03 11:48:51','2026-08-03 11:48:51',NULL,NULL),
(4,'Pratap Nagar Shop',5,1,NULL,13,14,0,0,'RC','pratap nagar jaipur','26.8808145','75.7919299',NULL,NULL,NULL,NULL,1,NULL,'2026-08-03 15:28:58','2026-08-03 15:28:58',NULL,NULL);
/*!40000 ALTER TABLE `shops` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sizes`
--

DROP TABLE IF EXISTS `sizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sizes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `name_ar` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `shop_id` bigint(20) unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sizes_shop_id_foreign` (`shop_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sizes`
--

LOCK TABLES `sizes` WRITE;
/*!40000 ALTER TABLE `sizes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sizes` VALUES
(1,'small',NULL,1,1,'2026-08-03 11:17:58','2026-08-03 11:17:58'),
(2,'medium',NULL,1,1,'2026-08-03 11:18:07','2026-08-03 11:18:07'),
(3,'large',NULL,1,1,'2026-08-03 11:18:16','2026-08-03 11:18:16');
/*!40000 ALTER TABLE `sizes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `social_auths`
--

DROP TABLE IF EXISTS `social_auths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `social_auths` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `client_id` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `client_secret` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `redirect` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `provider` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `logo` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_auths`
--

LOCK TABLES `social_auths` WRITE;
/*!40000 ALTER TABLE `social_auths` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `social_auths` VALUES
(1,'Google','','','postmessage','google','assets/social/google.svg',0,NULL,NULL),
(2,'Facebook','','','','facebook','assets/social/facebook.svg',0,NULL,NULL),
(3,'Apple','com.janmitram.web','',NULL,'apple','assets/social/apple.svg',0,NULL,NULL);
/*!40000 ALTER TABLE `social_auths` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `social_links`
--

DROP TABLE IF EXISTS `social_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `social_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `logo` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` text COLLATE utf8_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_links`
--

LOCK TABLES `social_links` WRITE;
/*!40000 ALTER TABLE `social_links` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `social_links` VALUES
(1,'Facebook','/assets/social/facebook.png',NULL,1,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(2,'LinkedIn','/assets/social/linkedin.png','https://www.linkedin.com/company/razinsoft',1,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(3,'Instagram','/assets/social/instagram.png',NULL,1,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(4,'YouTube','/assets/social/youtube.png','https://www.youtube.com/@razinsoft',1,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(5,'WhatsApp','/assets/social/whatsapp.png',NULL,1,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(6,'Twitter','/assets/social/twitter.png',NULL,1,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(7,'Telegram','/assets/social/telegram.png',NULL,1,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(8,'Google Plus','/assets/social/google-plus.png',NULL,1,'2026-08-03 08:41:09','2026-08-03 08:41:09');
/*!40000 ALTER TABLE `social_links` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `stock_ledgers`
--

DROP TABLE IF EXISTS `stock_ledgers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_ledgers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `from_warehouse_id` bigint(20) unsigned DEFAULT NULL,
  `to_warehouse_id` bigint(20) unsigned DEFAULT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `color_id` bigint(20) unsigned DEFAULT NULL,
  `size_id` bigint(20) unsigned DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `reference_type` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `reference_id` bigint(20) unsigned DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_ledgers_from_warehouse_id_foreign` (`from_warehouse_id`),
  KEY `stock_ledgers_to_warehouse_id_foreign` (`to_warehouse_id`),
  KEY `stock_ledgers_product_id_foreign` (`product_id`),
  KEY `stock_ledgers_color_id_foreign` (`color_id`),
  KEY `stock_ledgers_size_id_foreign` (`size_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_ledgers`
--

LOCK TABLES `stock_ledgers` WRITE;
/*!40000 ALTER TABLE `stock_ledgers` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `stock_ledgers` VALUES
(1,NULL,1,1,1,1,500,'admin_addition',NULL,'500','2026-08-03 11:26:09','2026-08-03 11:26:09'),
(2,1,2,1,1,1,100,'warehouse_transfer',1,'100','2026-08-03 11:26:39','2026-08-03 11:26:39'),
(3,2,NULL,1,NULL,NULL,50,'shop_request',1,'Fulfilled stock request #1 for shop #2','2026-08-03 11:50:48','2026-08-03 11:50:48');
/*!40000 ALTER TABLE `stock_ledgers` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `stock_request_items`
--

DROP TABLE IF EXISTS `stock_request_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_request_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `stock_request_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `color_id` bigint(20) unsigned DEFAULT NULL,
  `size_id` bigint(20) unsigned DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_request_items_stock_request_id_foreign` (`stock_request_id`),
  KEY `stock_request_items_product_id_foreign` (`product_id`),
  KEY `stock_request_items_color_id_foreign` (`color_id`),
  KEY `stock_request_items_size_id_foreign` (`size_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_request_items`
--

LOCK TABLES `stock_request_items` WRITE;
/*!40000 ALTER TABLE `stock_request_items` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `stock_request_items` VALUES
(1,1,1,NULL,NULL,50,'2026-08-03 11:50:34','2026-08-03 11:50:34');
/*!40000 ALTER TABLE `stock_request_items` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `stock_requests`
--

DROP TABLE IF EXISTS `stock_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_requests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `shop_id` bigint(20) unsigned NOT NULL,
  `warehouse_id` bigint(20) unsigned NOT NULL,
  `status` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'pending',
  `notes` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_requests_shop_id_foreign` (`shop_id`),
  KEY `stock_requests_warehouse_id_foreign` (`warehouse_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_requests`
--

LOCK TABLES `stock_requests` WRITE;
/*!40000 ALTER TABLE `stock_requests` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `stock_requests` VALUES
(1,2,2,'completed','50','2026-08-03 11:50:34','2026-08-03 11:50:48');
/*!40000 ALTER TABLE `stock_requests` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sub_categories`
--

DROP TABLE IF EXISTS `sub_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sub_categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `media_id` bigint(20) unsigned DEFAULT NULL,
  `shop_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `name_ar` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sub_categories_media_id_foreign` (`media_id`),
  KEY `sub_categories_shop_id_foreign` (`shop_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sub_categories`
--

LOCK TABLES `sub_categories` WRITE;
/*!40000 ALTER TABLE `sub_categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sub_categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `support_ticket_attachments`
--

DROP TABLE IF EXISTS `support_ticket_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_ticket_attachments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `support_ticket_id` bigint(20) unsigned NOT NULL,
  `media_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `support_ticket_attachments_support_ticket_id_foreign` (`support_ticket_id`),
  KEY `support_ticket_attachments_media_id_foreign` (`media_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_ticket_attachments`
--

LOCK TABLES `support_ticket_attachments` WRITE;
/*!40000 ALTER TABLE `support_ticket_attachments` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `support_ticket_attachments` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `support_ticket_messages`
--

DROP TABLE IF EXISTS `support_ticket_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_ticket_messages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `support_ticket_id` bigint(20) unsigned NOT NULL,
  `sender_id` bigint(20) unsigned DEFAULT NULL,
  `is_highlighted` tinyint(1) NOT NULL DEFAULT '0',
  `message` longtext COLLATE utf8_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `support_ticket_messages_support_ticket_id_foreign` (`support_ticket_id`),
  KEY `support_ticket_messages_sender_id_foreign` (`sender_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_ticket_messages`
--

LOCK TABLES `support_ticket_messages` WRITE;
/*!40000 ALTER TABLE `support_ticket_messages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `support_ticket_messages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `support_tickets`
--

DROP TABLE IF EXISTS `support_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_tickets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `ticket_number` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `order_number` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `issue_type` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subject` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8_unicode_ci,
  `status` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'pending',
  `email` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ticket_start` timestamp NULL DEFAULT NULL,
  `ticket_end` timestamp NULL DEFAULT NULL,
  `user_chat` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `support_tickets_user_id_foreign` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_tickets`
--

LOCK TABLES `support_tickets` WRITE;
/*!40000 ALTER TABLE `support_tickets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `support_tickets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `supports`
--

DROP TABLE IF EXISTS `supports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `supports` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `email` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `supports_customer_id_foreign` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supports`
--

LOCK TABLES `supports` WRITE;
/*!40000 ALTER TABLE `supports` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `supports` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `theme_colors`
--

DROP TABLE IF EXISTS `theme_colors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `theme_colors` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `primary` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `secondary` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `variant_50` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `variant_100` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `variant_200` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `variant_300` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `variant_400` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `variant_500` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `variant_600` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `variant_700` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `variant_800` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `variant_900` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `variant_950` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `theme_colors`
--

LOCK TABLES `theme_colors` WRITE;
/*!40000 ALTER TABLE `theme_colors` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `theme_colors` VALUES
(1,'#EE456B','#FEE5E8','#FFF1F3','#FEE5E8','#FCCFD6','#FAA7B5','#F7758F','#EE456B','#DD2C5C','#B91747','#9B1642','#84173E','#4A071D',1,'2026-08-03 08:41:09','2026-08-03 08:41:09'),
(2,'#a855f7','#f3e8ff','#faf5ff','#f3e8ff','#e9d5ff','#d8b4fe','#c084fc','#a855f7','#9333ea','#7e22ce','#6b21a8','#581c87','#3b0764',0,NULL,NULL),
(3,'#8b5cf6','#ede9fe','#f5f3ff','#ede9fe','#ddd6fe','#c4b5fd','#a78bfa','#8b5cf6','#7c3aed','#6d28d9','#5b21b6','#4c1d95','#2e1065',0,NULL,NULL);
/*!40000 ALTER TABLE `theme_colors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `ticket_issue_types`
--

DROP TABLE IF EXISTS `ticket_issue_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket_issue_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_issue_types`
--

LOCK TABLES `ticket_issue_types` WRITE;
/*!40000 ALTER TABLE `ticket_issue_types` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `ticket_issue_types` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `wallet_id` bigint(20) unsigned NOT NULL,
  `amount` double NOT NULL DEFAULT '0',
  `is_commission` tinyint(1) NOT NULL DEFAULT '0',
  `type` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'credit',
  `transaction_id` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `purpose` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transactions_wallet_id_foreign` (`wallet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `translate_utilities`
--

DROP TABLE IF EXISTS `translate_utilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `translate_utilities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `sub_category_id` bigint(20) unsigned DEFAULT NULL,
  `brand_id` bigint(20) unsigned DEFAULT NULL,
  `color_id` bigint(20) unsigned DEFAULT NULL,
  `size_id` bigint(20) unsigned DEFAULT NULL,
  `unit_id` bigint(20) unsigned DEFAULT NULL,
  `lang` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `translate_utilities_category_id_foreign` (`category_id`),
  KEY `translate_utilities_sub_category_id_foreign` (`sub_category_id`),
  KEY `translate_utilities_brand_id_foreign` (`brand_id`),
  KEY `translate_utilities_color_id_foreign` (`color_id`),
  KEY `translate_utilities_size_id_foreign` (`size_id`),
  KEY `translate_utilities_unit_id_foreign` (`unit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `translate_utilities`
--

LOCK TABLES `translate_utilities` WRITE;
/*!40000 ALTER TABLE `translate_utilities` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `translate_utilities` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `units`
--

DROP TABLE IF EXISTS `units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `units` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `shop_id` bigint(20) unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `units_shop_id_foreign` (`shop_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `units`
--

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `units` VALUES
(1,'1 KG',1,1,'2026-08-03 11:18:34','2026-08-03 11:18:34'),
(2,'500 GM',1,1,'2026-08-03 11:18:47','2026-08-03 11:18:47'),
(3,'250 GM',1,1,'2026-08-03 11:19:03','2026-08-03 11:19:03');
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `user_non_permissions`
--

DROP TABLE IF EXISTS `user_non_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_non_permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_non_permissions_user_id_foreign` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_non_permissions`
--

LOCK TABLES `user_non_permissions` WRITE;
/*!40000 ALTER TABLE `user_non_permissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `user_non_permissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `media_id` bigint(20) unsigned DEFAULT NULL,
  `password` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `phone_verified_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `driving_lience` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vehicle_type` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `country` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone_code` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `shop_id` bigint(20) unsigned DEFAULT NULL,
  `auth_type` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_id` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_online` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `users_media_id_foreign` (`media_id`),
  KEY `users_shop_id_foreign` (`shop_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES
(1,'Super Admin',NULL,'01000000001','root@janmitram.com',NULL,'$2y$12$hHv82ChVVioypklqriMuvuosPk2qygbizrBnv/Iwnpsj/.SO071Lq',NULL,NULL,1,'2026-08-03 08:41:09','2026-08-03 08:41:09',NULL,NULL,NULL,'2026-08-03 08:41:09','2026-08-03 08:41:09',NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(3,'Chandan','Gaur','9549803319','chg@janmitram.com',6,'$2y$12$8ijlsp1DRwpKSj33wA16zORdKdG/X69g7OJJssi79fmQvQu2szjN2','male',NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-08-03 11:44:54','2026-08-03 11:44:54',NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4,'Shubham','Gaur','9549803300','shg@janmitram.com',9,'$2y$12$ytIdZYyfw3yg4xl./WuEyu5HtRyUwPBttZ4qQL6I5Gbb6Qzi.6HbS','male',NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-08-03 11:48:51','2026-08-03 11:48:51',NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(5,'Chandan2','Gaur','9549803311','chg2@janmitram.com',12,'$2y$12$OqEIoEjY70CwPdXLw5CvA.wIftWhG0bdcnoiDdjZibgjGmkFgmBeq','male',NULL,0,NULL,NULL,NULL,NULL,NULL,'2026-08-03 15:28:58','2026-08-03 15:28:58',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `vat_taxes`
--

DROP TABLE IF EXISTS `vat_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `vat_taxes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(191) COLLATE utf8_unicode_ci DEFAULT 'order_base',
  `name` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `percentage` double NOT NULL DEFAULT '0',
  `deduction` varchar(191) COLLATE utf8_unicode_ci DEFAULT 'exclusive',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vat_taxes`
--

LOCK TABLES `vat_taxes` WRITE;
/*!40000 ALTER TABLE `vat_taxes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `vat_taxes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `verify_manages`
--

DROP TABLE IF EXISTS `verify_manages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `verify_manages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `register_otp` tinyint(1) NOT NULL DEFAULT '0',
  `register_otp_type` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `forgot_otp` tinyint(1) NOT NULL DEFAULT '1',
  `forgot_otp_type` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `phone_required` tinyint(1) NOT NULL DEFAULT '1',
  `email_required` tinyint(1) NOT NULL DEFAULT '0',
  `phone_min_length` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone_max_length` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order_place_account_verify` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verify_manages`
--

LOCK TABLES `verify_manages` WRITE;
/*!40000 ALTER TABLE `verify_manages` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `verify_manages` VALUES
(1,0,'email',1,'email',NULL,NULL,0,1,'9','16',0);
/*!40000 ALTER TABLE `verify_manages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `verify_otps`
--

DROP TABLE IF EXISTS `verify_otps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `verify_otps` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `phone` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `otp` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verify_otps`
--

LOCK TABLES `verify_otps` WRITE;
/*!40000 ALTER TABLE `verify_otps` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `verify_otps` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `wallets`
--

DROP TABLE IF EXISTS `wallets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wallets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `balance` double NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wallets_user_id_foreign` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wallets`
--

LOCK TABLES `wallets` WRITE;
/*!40000 ALTER TABLE `wallets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `wallets` VALUES
(1,1,0,'2026-08-03 08:41:11','2026-08-03 08:41:11'),
(2,2,0,'2026-08-03 08:41:11','2026-08-03 08:41:11'),
(3,3,0,'2026-08-03 11:44:54','2026-08-03 11:44:54'),
(4,4,0,'2026-08-03 11:48:51','2026-08-03 11:48:51'),
(5,5,0,'2026-08-03 15:28:58','2026-08-03 15:28:58');
/*!40000 ALTER TABLE `wallets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `warehouse_stock`
--

DROP TABLE IF EXISTS `warehouse_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `warehouse_stock` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `warehouse_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `color_id` bigint(20) unsigned DEFAULT NULL,
  `size_id` bigint(20) unsigned DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wh_stock_unique` (`warehouse_id`,`product_id`,`color_id`,`size_id`),
  KEY `warehouse_stock_product_id_foreign` (`product_id`),
  KEY `warehouse_stock_color_id_foreign` (`color_id`),
  KEY `warehouse_stock_size_id_foreign` (`size_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `warehouse_stock`
--

LOCK TABLES `warehouse_stock` WRITE;
/*!40000 ALTER TABLE `warehouse_stock` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `warehouse_stock` VALUES
(1,1,1,1,1,400,'2026-08-03 11:26:09','2026-08-03 11:26:39'),
(2,2,1,1,1,50,'2026-08-03 11:26:39','2026-08-03 11:50:48');
/*!40000 ALTER TABLE `warehouse_stock` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `warehouse_transfer_items`
--

DROP TABLE IF EXISTS `warehouse_transfer_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `warehouse_transfer_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `warehouse_transfer_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `color_id` bigint(20) unsigned DEFAULT NULL,
  `size_id` bigint(20) unsigned DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `warehouse_transfer_items_warehouse_transfer_id_foreign` (`warehouse_transfer_id`),
  KEY `warehouse_transfer_items_product_id_foreign` (`product_id`),
  KEY `warehouse_transfer_items_color_id_foreign` (`color_id`),
  KEY `warehouse_transfer_items_size_id_foreign` (`size_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `warehouse_transfer_items`
--

LOCK TABLES `warehouse_transfer_items` WRITE;
/*!40000 ALTER TABLE `warehouse_transfer_items` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `warehouse_transfer_items` VALUES
(1,1,1,NULL,NULL,100,'2026-08-03 11:26:34','2026-08-03 11:26:34');
/*!40000 ALTER TABLE `warehouse_transfer_items` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `warehouse_transfers`
--

DROP TABLE IF EXISTS `warehouse_transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `warehouse_transfers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `from_warehouse_id` bigint(20) unsigned NOT NULL,
  `to_warehouse_id` bigint(20) unsigned NOT NULL,
  `status` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'pending',
  `notes` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `warehouse_transfers_from_warehouse_id_foreign` (`from_warehouse_id`),
  KEY `warehouse_transfers_to_warehouse_id_foreign` (`to_warehouse_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `warehouse_transfers`
--

LOCK TABLES `warehouse_transfers` WRITE;
/*!40000 ALTER TABLE `warehouse_transfers` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `warehouse_transfers` VALUES
(1,1,2,'completed','100','2026-08-03 11:26:34','2026-08-03 11:26:39');
/*!40000 ALTER TABLE `warehouse_transfers` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `warehouses`
--

DROP TABLE IF EXISTS `warehouses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `warehouses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `address` text COLLATE utf8_unicode_ci,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `warehouses`
--

LOCK TABLES `warehouses` WRITE;
/*!40000 ALTER TABLE `warehouses` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `warehouses` VALUES
(1,'Central Warehouse','Main Logistics Hub',1,'2026-08-03 08:41:11','2026-08-03 08:41:11'),
(2,'Sanganer Shop','Sanganer Jaipur',0,'2026-08-03 11:25:12','2026-08-03 11:25:12');
/*!40000 ALTER TABLE `warehouses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `withdraws`
--

DROP TABLE IF EXISTS `withdraws`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `withdraws` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `shop_id` bigint(20) unsigned DEFAULT NULL,
  `amount` double NOT NULL DEFAULT '0',
  `contact_number` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `withdraw_method` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reason` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `withdraws_user_id_foreign` (`user_id`),
  KEY `withdraws_shop_id_foreign` (`shop_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `withdraws`
--

LOCK TABLES `withdraws` WRITE;
/*!40000 ALTER TABLE `withdraws` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `withdraws` ENABLE KEYS */;
UNLOCK TABLES;
commit;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-08-03 20:53:54
